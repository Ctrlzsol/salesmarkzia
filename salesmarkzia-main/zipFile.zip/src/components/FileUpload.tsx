import React, { useRef, useState } from "react";
import { UploadCloud, Loader2, Sparkles, AlertCircle, FileSpreadsheet, PlayCircle, Utensils, ChefHat, Flame } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import * as XLSX from "xlsx";
import { SaleRecord } from "../types";
import { getDummyData } from "../lib/dummyData";

interface FileUploadProps {
  onUpload: (data: SaleRecord[]) => void;
  isAnalyzing: boolean;
}

export function AlMarkaziaLogo({ className = "h-16" }: { className?: string }) {
  return (
    <div className={`flex flex-col items-center justify-center gap-2 ${className}`}>
      {/* Premium Luxury Gold/Emerald Shield for Al-Markazia */}
      <svg viewBox="0 0 500 140" className="w-full h-full max-w-[340px] md:max-w-[420px]" fill="none" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <linearGradient id="goldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#D4AF37" />
            <stop offset="100%" stopColor="#AA7C11" />
          </linearGradient>
          <linearGradient id="emeraldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#10B981" />
            <stop offset="100%" stopColor="#047857" />
          </linearGradient>
          <linearGradient id="slateGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#1E293B" />
            <stop offset="100%" stopColor="#0F172A" />
          </linearGradient>
          <filter id="shieldShadow" x="-5" y="-5" width="510" height="150" filterUnits="userSpaceOnUse">
            <feDropShadow dx="0" dy="8" stdDeviation="6" floodColor="#047857" floodOpacity="0.08" />
          </filter>
        </defs>
        
        <g filter="url(#shieldShadow)">
          {/* Outer elegant gold hexagon panel */}
          <path d="M 40 15 L 140 15 Q 155 15, 160 30 L 175 75 Q 180 90, 165 105 L 105 130 Q 95 135, 85 130 L 25 105 Q 10 90, 15 75 L 30 30 Q 35 15, 40 15 Z" fill="url(#slateGrad)" stroke="url(#goldGrad)" strokeWidth="2" />
          
          {/* Inner reflective geometric facet */}
          <path d="M 45 25 L 135 25 L 155 75 L 95 120 L 35 75 Z" fill="url(#emeraldGrad)" opacity="0.15" />
          
          {/* Intertwined Arabic Geometric Motif (Dynamic lines for data layers) */}
          <line x1="50" y1="40" x2="140" y2="110" stroke="#D4AF37" strokeWidth="1.5" strokeDasharray="3 3" opacity="0.6" />
          <line x1="140" y1="40" x2="50" y2="110" stroke="#D4AF37" strokeWidth="1.5" strokeDasharray="3 3" opacity="0.6" />
          
          {/* Central emblem: Flame / Arrow of growth */}
          <path d="M 95 40 L 115 75 L 105 75 L 105 100 L 85 100 L 85 75 L 75 75 Z" fill="url(#goldGrad)" />
          
          {/* Brand name and subtitle */}
          <text x="200" y="80" fontFamily="'Inter', 'Tajawal', sans-serif" fontWeight="900" fontSize="48" fill="#0F172A" letterSpacing="0.5">AL-MARKAZIA</text>
          
          {/* Subtitle with premium gold branding */}
          <text x="202" y="108" fontFamily="'Inter', 'Tajawal', sans-serif" fontWeight="700" fontSize="14" fill="#AA7C11" letterSpacing="1">DECISION SUPPORT ENGINE | محرك دعم القرار المالي</text>
        </g>
      </svg>
    </div>
  );
}

export function FileUpload({ onUpload, isAnalyzing: externalIsAnalyzing }: FileUploadProps) {
  const [isReadingFile, setIsReadingFile] = useState(false);
  const [loaderMsg, setLoaderMsg] = useState("جاري تحليل الملف...");
  const [loaderSub, setLoaderSub] = useState("يرجى الانتظار...");
  const [loaderPct, setLoaderPct] = useState(0);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

  const animatePct = async (from: number, to: number, duration: number) => {
    const steps = 15;
    const stepTime = duration / steps;
    const increment = (to - from) / steps;
    let current = from;
    for (let i = 0; i < steps; i++) {
      current += increment;
      setLoaderPct(Math.round(current));
      await delay(stepTime);
    }
    setLoaderPct(to);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  const processFile = async (file: File) => {
    setErrorMsg(null);
    setIsReadingFile(true);
    setLoaderPct(5);
    setLoaderMsg("جاري الاتصال بالملف ورصد البيانات...");
    setLoaderSub(file.name);

    try {
      await delay(150);
      await animatePct(5, 25, 200);

      const dataArray = await file.arrayBuffer();
      await animatePct(25, 45, 150);
      
      const workbook = XLSX.read(dataArray, { type: "array", cellDates: true });
      const sheetsList = workbook.SheetNames;
      
      await animatePct(45, 60, 150);

      setLoaderMsg("جاري تنظيم وترجمة وتدقيق البيانات المطابقة لـ المركزية...");
      setLoaderSub("استخراج قنوات الكاش والدفع الإلكتروني والتطبيقات");
      await animatePct(60, 90, 250);

      const parsedRecords = parseExcelData(workbook);

      if (parsedRecords.length === 0) {
        throw new Error("لم نتمكن من استيراد مبيعات مطابقة في هذا الملف. تأكد من وجود أرقام مبيعات وتفاصيل في قنوات الدفع (الفرع، الكاشير، كاش، فيزا..)");
      }

      await animatePct(90, 100, 150);
      await delay(200);

      setIsReadingFile(false);
      onUpload(parsedRecords);

    } catch (err: any) {
      console.error(err);
      setIsReadingFile(false);
      setErrorMsg(err.message || "عفواً، فشل استيراد الملف. يرجى مراجعة التنسيق وتجربة ملف آخر.");
    }
  };

  const parseExcelData = (workbook: XLSX.WorkBook): SaleRecord[] => {
    const results: SaleRecord[] = [];

    const CASHIER_MAP: Record<string, string> = {
      haya: "هيا قلاب",
      rami: "رامي شديد",
      diaa: "ضياء المريسي",
      mohd: "محمد الخطيب",
      hr: "حسين رمضان",
      hh: "حسين حماد",
      app: "تطبيقات",
      adh: "اضاحي",
      "عام": "كاشير عام",
    };

    const DEPT_MAP: Record<string, string> = {
      mlh: "قسم الملحمة",
      ln: "قسم اللاين",
      slh: "قسم الصالة",
      swn: "قسم الصواني",
      msh: "قسم المشروبات",
      tws: "قسم التواصي",
      frn: "قسم الفرن",
      mqb: "قسم المقبلات",
      mshw: "قسم المشاوي",
      adh: "اضاحي",
      "عام": "قسم عام"
    };

    const DAY_MAP: Record<string, string> = {
      Mon: "Mon", Tue: "Tue", Wed: "Wed", Thu: "Thu", Fri: "Fri", Sat: "Sat", Sun: "Sun",
      الاثنين: "Mon", الثلاثاء: "Tue", الأربعاء: "Wed", الخميس: "Thu", الجمعة: "Fri", السبت: "Sat", الأحد: "Sun",
      اثنين: "Mon", ثلاثاء: "Tue", اربعاء: "Wed", خميس: "Thu", جمعة: "Fri", سبت: "Sat", احد: "Sun"
    };

    const DAY_NAMES_AR: Record<string, string> = {
      Mon: "الاثنين", Tue: "الثلاثاء", Wed: "الأربعاء", Thu: "الخميس", Fri: "الجمعة", Sat: "السبت", Sun: "الأحد"
    };

    const BRANCH_MAP_AR: Record<string, string> = {
      G: "الجاردنز", K: "خلدا", X: "أخرى",
      الجاردنز: "الجاردنز", خلدا: "خلدا", أخرى: "أخرى", اخري: "أخرى"
    };

    const CAT_MAP_AR: Record<string, string> = {
      R: "مطعم", A: "تطبيقات", O: "أخرى",
      مطعم: "مطعم", تطبيقات: "تطبيقات", تطبيق: "تطبيقات", أخرى: "أخرى", اخري: "أخرى"
    };

    const parseDateAndDay = (cellVal: any): { dateObj: Date, day: string } => {
      const defaultDate = new Date(2026, 5, 1, 12, 0, 0); // Default stable date (June 1st, 2026, Monday)
      const DAYS_ORDER = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

      if (cellVal === undefined || cellVal === null || cellVal === "") {
        return { dateObj: defaultDate, day: "Mon" };
      }

      // If it is already a JS Date object
      if (cellVal instanceof Date) {
        if (!isNaN(cellVal.getTime())) {
          return { dateObj: cellVal, day: DAYS_ORDER[cellVal.getDay()] };
        }
      }

      // If it is a number (e.g. excel serial date)
      if (typeof cellVal === "number") {
        if (cellVal > 30000 && cellVal < 60000) {
          const jsDate = new Date((cellVal - 25569) * 86400 * 1000);
          if (!isNaN(jsDate.getTime())) {
            return { dateObj: jsDate, day: DAYS_ORDER[jsDate.getDay()] };
          }
        }
      }

      const str = String(cellVal).trim();
      if (!str) return { dateObj: defaultDate, day: "Mon" };

      // Try parsing standard ISO/Date formats
      const parsedTs = Date.parse(str);
      if (!isNaN(parsedTs)) {
        const jsDate = new Date(parsedTs);
        return { dateObj: jsDate, day: DAYS_ORDER[jsDate.getDay()] };
      }

      // Custom split patterns like DD/MM/YYYY or MM-DD-YYYY or D/M
      const regex = /(\d+)[-/.](\d+)[-/.]?(\d+)?/;
      const match = str.match(regex);
      if (match) {
        const val1 = parseInt(match[1], 10);
        const val2 = parseInt(match[2], 10);
        const val3 = match[3] ? parseInt(match[3], 10) : 2026;
        
        let year = val3 < 100 ? 2000 + val3 : val3;
        let month = 5; // Default June
        let dayVal = 1;

        if (val1 > 12) { // style: YYYY-MM-DD or DD-MM-YYYY
          if (val1 > 1000) { // YYYY-MM-DD
            year = val1;
            month = (val2 - 1) % 12;
            dayVal = val3 || 1;
          } else { // DD-MM-YYYY
            dayVal = val1;
            month = (val2 - 1) % 12;
          }
        } else if (val2 > 12) { // MM-DD-YYYY
          month = (val1 - 1) % 12;
          dayVal = val2;
        } else { // DD-MM
          dayVal = val1;
          month = (val2 - 1) % 12;
        }

        const jsDate = new Date(year, month, dayVal, 12, 0, 0);
        if (!isNaN(jsDate.getTime())) {
          return { dateObj: jsDate, day: DAYS_ORDER[jsDate.getDay()] };
        }
      }

      return { dateObj: defaultDate, day: "Mon" };
    };

    const parseNumClean = (val: any): number => {
      if (val === undefined || val === null || val === "") return 0;
      if (typeof val === "number") return val;
      const clean = String(val).replace(/[^\d.-]/g, "");
      const parsed = parseFloat(clean);
      return isNaN(parsed) ? 0 : parsed;
    };

    // Iterate sheets in the Excel workbook
    workbook.SheetNames.forEach((sheetName) => {
      const worksheet = workbook.Sheets[sheetName];
      const rows = XLSX.utils.sheet_to_json<any[]>(worksheet, { header: 1, defval: "" });

      if (rows.length < 2) return;

      // 1. Identify Header Row of this sheet dynamically
      let headerRowIndex = -1;
      let colMap: Record<string, number> = {
        date: -1,
        branch: -1,
        cat: -1,
        cashier: -1,
        dept: -1,
        day: -1,
        visa: -1,
        cash: -1,
        klik: -1,
        orders: -1,
        cream: -1,
        ashyaei: -1,
        callcenter: -1,
        other: -1,
      };

      // Search first 50 rows for headers
      for (let rIdx = 0; rIdx < Math.min(rows.length, 50); rIdx++) {
        const row = rows[rIdx];
        if (!Array.isArray(row)) continue;

        let matchCount = 0;
        row.forEach((cell, cIdx) => {
          const str = String(cell || "").trim().toLowerCase();
          if (!str) return;

          if (str.includes("كاش") || str.includes("نقدا") || str.includes("نقدي") || str.includes("نقد") || str.includes("cash")) matchCount++;
          if (str.includes("فيزا") || str.includes("بطاقة") || str.includes("شبكة") || str.includes("مدى") || str.includes("visa")) matchCount++;
          if (str.includes("كليك") || str.includes("clik") || str.includes("cliq") || str.includes("klik")) matchCount++;
          if (str.includes("القسم") || str.includes("قسم") || str.includes("الفرع") || str.includes("فرع") || str.includes("branch") || str.includes("dept")) matchCount++;
        });

        // If we found at least 2 key terms, assume it's the header row
        if (matchCount >= 2) {
          headerRowIndex = rIdx;
          row.forEach((cell, cIdx) => {
            const str = String(cell || "").trim().toLowerCase();
            if (!str) return;

            if (str.includes("تاريخ") || str.includes("التاريخ") || str.includes("date")) {
              colMap.date = cIdx;
            } else if (str.includes("فرع") || str.includes("الفرع") || str.includes("branch")) {
              colMap.branch = cIdx;
            } else if (str.includes("نوع") || str.includes("تصنيف") || str.includes("cat")) {
              colMap.cat = cIdx;
            } else if (str.includes("كاشير") || str.includes("الكاشير") || str.includes("اسم") || str.includes("cashier")) {
              colMap.cashier = cIdx;
            } else if (str.includes("القسم") || str.includes("قسم") || str.includes("dept") || str.includes("العنصر")) {
              colMap.dept = cIdx;
            } else if (str.includes("يوم") || str.includes("اليوم") || str.includes("day")) {
              colMap.day = cIdx;
            } else if (str.includes("فيزا") || str.includes("شبكة") || str.includes("بطاقة") || str.includes("visa") || str.includes("card") || str.includes("سداد")) {
              colMap.visa = cIdx;
            } else if (str.includes("كاش") || str.includes("نقدا") || str.includes("نقدي") || str.includes("نقد") || str.includes("cash")) {
              colMap.cash = cIdx;
            } else if (str.includes("كليك") || str.includes("clik") || str.includes("cliq") || str.includes("klik")) {
              colMap.klik = cIdx;
            } else if (str.includes("طلب") || str.includes("تطبيقات") || str.includes("delivery") || str.includes("order") || str.includes("تطبيق")) {
              colMap.orders = cIdx;
            } else if (str.includes("كريمة") || str.includes("كريم") || str.includes("cream")) {
              colMap.cream = cIdx;
            } else if (str.includes("عشيائي") || str.includes("اشيائي") || str.includes("ashyaei")) {
              colMap.ashyaei = cIdx;
            } else if (str.includes("كولسنتر") || str.includes("كول") || str.includes("callcenter")) {
              colMap.callcenter = cIdx;
            } else if (str.includes("أخرى") || str.includes("اخرى") || str.includes("other") || str.includes("إضافي")) {
              colMap.other = cIdx;
            }

            // Fallback for general sales column if no cash/visa defined
            if (colMap.cash === -1 && colMap.visa === -1) {
              if (str.includes("إجمالي") || str.includes("اجمالي") || str.includes("المجموع") || str.includes("مبيعات") || str.includes("المبلغ") || str.includes("القيمة") || str.includes("total") || str.includes("sales") || str.includes("amount") || str.includes("سعر")) {
                colMap.cash = cIdx;
              }
            }
          });
          break;
        }
      }

      // 2. Loop row data starting after the header
      const startRowIdx = headerRowIndex !== -1 ? headerRowIndex + 1 : 0;

      for (let rIdx = startRowIdx; rIdx < rows.length; rIdx++) {
        const row = rows[rIdx];
        if (!Array.isArray(row) || row.length < 3) continue;

        // Skip rows that look like summary/total titles or are empty
        const rowText = row.map(c => String(c || "").trim()).join(" ");
        if (rowText.includes("المجموع") || rowText.includes("الاجمالي") || rowText.includes("إجمالي") || rowText.includes("total") || rowText.includes("sum") || !rowText.trim()) {
          continue;
        }

        let cat = "R";
        let branch = "G";
        let cashier = "عام";
        let dept = "عام";
        let rawDateVal: any = null;
        let detectedDay: string | null = null;

        // Try to match values intelligently from column map, or deduce if they contain keywords
        row.forEach((cellVal, cIdx) => {
          const strCell = String(cellVal || "").trim();

          // Check if this column represents specific info based on matched header index
          if (cIdx === colMap.date) {
            rawDateVal = cellVal;
          } else if (cIdx === colMap.branch) {
            if (strCell.includes("جاردنز") || strCell.toLowerCase().includes("garden")) branch = "G";
            else if (strCell.includes("خلدا") || strCell.toLowerCase().includes("khild")) branch = "K";
          } else if (cIdx === colMap.cat) {
            if (strCell.includes("مطعم") || strCell.includes("صالة")) cat = "R";
            else if (strCell.includes("تطبيقات") || strCell.includes("تطبيق")) cat = "A";
          } else if (cIdx === colMap.cashier) {
            for (const [k, ar] of Object.entries(CASHIER_MAP)) {
              if (strCell.toLowerCase().includes(k.toLowerCase()) || ar.includes(strCell)) {
                cashier = k;
              }
            }
          } else if (cIdx === colMap.dept) {
            for (const [k, ar] of Object.entries(DEPT_MAP)) {
              if (strCell.toLowerCase().includes(k.toLowerCase()) || ar.includes(strCell)) {
                dept = k;
              }
            }
          } else if (cIdx === colMap.day) {
            for (const [key, std] of Object.entries(DAY_MAP)) {
              if (strCell.toLowerCase().includes(key.toLowerCase())) {
                detectedDay = std;
              }
            }
          }

          // Dynamic scans as helper if header is not defined or is missing some cols
          if (colMap.branch === -1) {
            if (strCell.includes("جاردنز") || strCell.toLowerCase().includes("garden")) branch = "G";
            else if (strCell.includes("خلدا") || strCell.toLowerCase().includes("khild")) branch = "K";
          }
          if (colMap.cat === -1) {
            if (strCell.includes("مطعم") || strCell.includes("صالة") || strCell.includes("محلي")) cat = "R";
            else if (strCell.includes("تطبيقات") || strCell.includes("تطبيق")) cat = "A";
          }
          if (colMap.day === -1) {
            for (const [key, std] of Object.entries(DAY_MAP)) {
              if (strCell.toLowerCase().includes(key.toLowerCase())) detectedDay = std;
            }
          }
          if (colMap.date === -1) {
            if (cellVal instanceof Date || (typeof cellVal === "number" && cellVal > 40000 && cellVal < 55000) || /\d{1,2}\/\d{1,2}/.test(strCell)) {
              rawDateVal = cellVal;
            }
          }
        });

        // Read numerical columns with absolute indexes depending on if header is mapped
        let visa = 0;
        let cash = 0;
        let klik = 0;
        let orders = 0;
        let cream = 0;
        let ashyaei = 0;
        let callcenter = 0;
        let other = 0;

        if (headerRowIndex !== -1) {
          if (colMap.visa !== -1) visa = parseNumClean(row[colMap.visa]);
          if (colMap.cash !== -1) cash = parseNumClean(row[colMap.cash]);
          if (colMap.klik !== -1) klik = parseNumClean(row[colMap.klik]);
          if (colMap.orders !== -1) orders = parseNumClean(row[colMap.orders]);
          if (colMap.cream !== -1) cream = parseNumClean(row[colMap.cream]);
          if (colMap.ashyaei !== -1) ashyaei = parseNumClean(row[colMap.ashyaei]);
          if (colMap.callcenter !== -1) callcenter = parseNumClean(row[colMap.callcenter]);
          if (colMap.other !== -1) other = parseNumClean(row[colMap.other]);
        } else {
          // No header row matched, deduce positionally while keeping zero cells intact (no filter)
          const numValues: number[] = row.map(d => parseNumClean(d));
          const possibleNums = numValues.map((v, idx) => ({ v, idx })).filter(item => item.idx >= 2);
          if (possibleNums.length >= 2) {
            visa = possibleNums[0]?.v || 0;
            cash = possibleNums[1]?.v || 0;
            klik = possibleNums[2]?.v || 0;
            orders = possibleNums[3]?.v || 0;
            cream = possibleNums[4]?.v || 0;
            ashyaei = possibleNums[5]?.v || 0;
            callcenter = possibleNums[6]?.v || 0;
            other = possibleNums[7]?.v || 0;
          }
        }

        const total = visa + cash + klik + orders + cream + ashyaei + callcenter + other;

        // Add if it represents real transactional data or department
        if (total > 0 || (dept !== "عام" && dept !== "قسم عام")) {
          const parsedDateResult = parseDateAndDay(rawDateVal);
          const dateObj = parsedDateResult.dateObj;
          const day = detectedDay || parsedDateResult.day;

          results.push({
            id: `ALM-${2000 + rIdx}-${sheetName}`,
            day,
            dayAr: DAY_NAMES_AR[day] || day,
            cat,
            catAr: CAT_MAP_AR[cat] || cat,
            date: dateObj.toISOString(),
            branch,
            branchAr: BRANCH_MAP_AR[branch] || branch,
            cashier,
            cashierAr: CASHIER_MAP[cashier] || CASHIER_MAP["عام"],
            dept,
            deptAr: DEPT_MAP[dept] || DEPT_MAP["عام"],
            visa,
            cash,
            klik,
            orders,
            cream,
            ashyaei,
            callcenter,
            other,
            total,
            sheetName: `ورقة ${sheetName}`,
          });
        }
      }
    });

    return results;
  };

  const handleDemoClick = () => {
    const demoData = getDummyData();
    onUpload(demoData);
  };

  const showLoader = isReadingFile || externalIsAnalyzing;
  const currentMsg = externalIsAnalyzing 
    ? "جاري معالجة وتدقيق مبيعات المركزية بالذكاء الاصطناعي..." 
    : loaderMsg;
  const currentSub = externalIsAnalyzing 
    ? "يتم الآن قراءة قنوات الدفع الإلكتروني، تفكيك الورديات، وتجهيز مصفوفة التوصيات الذكية لـ المركزية..." 
    : loaderSub;
  const currentPct = externalIsAnalyzing 
    ? 95 
    : loaderPct;

  return (
    <div className="min-h-screen bg-[#F8FAFC] flex flex-col items-center justify-center p-6 md:p-12 relative overflow-hidden select-none font-sans">
      <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-tr from-rose-50/20 via-indigo-50/20 to-amber-50/20 -z-10" />
      
      <AnimatePresence mode="wait">
        {showLoader ? (
          <motion.div
            key="loader"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="bg-white rounded-[2rem] p-10 md:p-14 shadow-2xl border border-slate-200/60 max-w-xl w-full text-center flex flex-col items-center gap-6 relative"
          >
            <div className="w-20 h-20 bg-amber-50 rounded-3xl flex items-center justify-center border border-amber-100 mb-2 relative">
              <Loader2 className="w-10 h-10 text-[#c76f00] animate-spin" />
            </div>
            
            <h3 className="text-xl font-black text-slate-900 tracking-tight">{currentMsg}</h3>
            <p className="text-sm font-semibold text-slate-400 -mt-2 leading-relaxed">{currentSub}</p>
            
            <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden mt-2 relative">
              <motion.div 
                className="bg-gradient-to-r from-[#c76f00] to-[#e8a030] h-full rounded-full"
                style={{ width: `${currentPct}%` }}
                layout
              />
            </div>
            <span className="text-[#c76f00] font-black font-mono text-base">{currentPct}%</span>
          </motion.div>
        ) : (
          <motion.div
            key="uploader"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            className="max-w-4xl w-full space-y-8 font-sans"
          >
            {/* Embedded custom CSS animations for the restaurant and system branding */}
            <style dangerouslySetInnerHTML={{__html: `
              @keyframes u-steam-1 {
                0% { transform: translateY(0) scaleX(0.9); opacity: 0; }
                40% { transform: translateY(-8px) scaleX(1.15); opacity: 0.8; }
                80% { transform: translateY(-16px) scaleX(0.9); opacity: 0.3; }
                100% { transform: translateY(-24px) scaleX(0.8); opacity: 0; }
              }
              @keyframes u-steam-2 {
                0% { transform: translateY(0) scaleX(1.1); opacity: 0; }
                30% { transform: translateY(-10px) scaleX(0.85); opacity: 0.9; }
                70% { transform: translateY(-18px) scaleX(1.1); opacity: 0.4; }
                100% { transform: translateY(-26px) scaleX(0.9); opacity: 0; }
              }
              @keyframes u-gentle-float {
                0%, 100% { transform: translateY(0px) rotate(0deg); }
                50% { transform: translateY(-6px) rotate(1.5deg); }
              }
              @keyframes u-spin-slow {
                0% { transform: rotate(0deg); }
                100% { transform: rotate(360deg); }
              }
              .steam-path-1 { animation: u-steam-1 3.5s infinite ease-in-out; }
              .steam-path-2 { animation: u-steam-2 4s infinite ease-in-out; }
              .steam-path-3 { animation: u-steam-1 4.5s infinite ease-in-out 1s; }
              .restaurant-float { animation: u-gentle-float 6s infinite ease-in-out; }
              .circle-spin { animation: u-spin-slow 20s infinite linear; }
            `}} />

            {/* Al-Markazia System Brand Header */}
            <div className="bg-white rounded-[2.5rem] p-8 md:p-12 border border-slate-200/60 shadow-xl text-center space-y-8 relative overflow-hidden">
               {/* Ambient decorative glowing backdrops */}
               <div className="absolute top-0 right-0 w-48 h-48 bg-emerald-50/50 rounded-full blur-3xl pointer-events-none"></div>
               <div className="absolute bottom-0 left-0 w-40 h-40 bg-amber-50/50 rounded-full blur-3xl pointer-events-none"></div>

               {/* Al-Markazia Logo with top padding */}
               <div className="relative z-10 pt-2">
                 <AlMarkaziaLogo className="h-16 mx-auto" />
               </div>

               {/* Restaurant Interactive Indicator Animation */}
               <div className="relative z-10 flex flex-col items-center justify-center">
                 <div className="restaurant-float relative flex items-center justify-center w-28 h-28 bg-gradient-to-tr from-[#1E293B] to-[#AA7C11] rounded-[2rem] shadow-lg shadow-amber-900/10 border-2 border-white/20">
                   {/* Spinning golden sparkles ring */}
                   <svg className="absolute w-32 h-32 circle-spin opacity-40" viewBox="0 0 100 100">
                     <circle cx="50" cy="50" r="46" stroke="#FFFFFF" strokeWidth="1.5" strokeDasharray="5 7" fill="none" />
                   </svg>

                   {/* Micro Steam icons rising from the culinary plate */}
                   <div className="absolute top-3 flex gap-2">
                     <span className="steam-path-1 block w-1 h-5 bg-gradient-to-t from-white/60 to-transparent rounded-full"></span>
                     <span className="steam-path-2 block w-1 h-7 bg-gradient-to-t from-amber-300/80 to-transparent rounded-full"></span>
                     <span className="steam-path-3 block w-1 h-5 bg-gradient-to-t from-white/60 to-transparent rounded-full"></span>
                   </div>

                   {/* Core cooking plate/cloche/chefs logo */}
                   <div className="flex flex-col items-center">
                     <ChefHat className="w-10 h-10 text-white drop-shadow-md mb-0.5" />
                     <div className="flex items-center gap-1.5 text-amber-300">
                       <Flame className="w-3.5 h-3.5 fill-amber-300 animate-pulse" />
                       <Utensils className="w-3.5 h-3.5" />
                     </div>
                   </div>
                 </div>
               </div>

               {/* Brand Texts and Client Identification */}
               <div className="space-y-4 relative z-10">
                 <div className="inline-flex items-center gap-2 bg-gradient-to-r from-[#1E293B]/5 to-[#AA7C11]/5 border border-[#1E293B]/15 text-[#1E293B] px-5 py-2 rounded-full text-xs font-black tracking-wider uppercase leading-none">
                   <Sparkles className="w-4 h-4 text-[#AA7C11] animate-pulse" />
                   <span>نظام المركزية المتكامل لتحليل مبيعات المطاعم والوجبات</span>
                 </div>
                 
                 <div className="space-y-1">
                   <h1 className="text-3xl md:text-5xl font-black text-slate-900 tracking-tight leading-none">
                     المرصد المالي والتشغيلي للمركزية
                   </h1>
                   <div className="pt-2 flex items-center justify-center gap-3">
                     <span className="h-px w-8 bg-[#AA7C11]/30"></span>
                     <p className="text-base md:text-lg text-emerald-800 font-extrabold tracking-wide uppercase">
                       إدارة الفروع: الجاردنز & خلدا
                     </p>
                     <span className="h-px w-8 bg-[#AA7C11]/30"></span>
                   </div>
                 </div>

                 <p className="text-xs md:text-sm text-slate-400 font-extrabold max-w-2xl mx-auto leading-relaxed">
                   نظام <span className="text-emerald-700 font-black">المركزية</span> الرقمي المتطور لرصد الإيرادات وتدقيق المطابقات والورديات اليومية. يتيح لك هذا المحرك كشف الفجوات فوراً ومحاكاة سيناريوهات النمو بدقة متناهية.
                 </p>
               </div>
            </div>



            {/* Dropzone Container */}
            <div
              onDragOver={handleDragOver}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className="bg-white border-2 border-dashed border-slate-200 hover:border-[#AA7C11] rounded-[2.5rem] p-12 text-center cursor-pointer hover:bg-amber-50/[0.02] shadow-xl group transition-all duration-300"
            >
              <input 
                type="file" 
                ref={fileInputRef} 
                onChange={handleFileInputChange} 
                accept=".xlsx,.xls,.csv" 
                className="hidden" 
              />
              
              <div className="w-20 h-20 bg-slate-50 border border-slate-100 rounded-3xl flex items-center justify-center mx-auto mb-6 group-hover:bg-[#1E293B]/5 group-hover:border-[#1E293B]/20 transition-all">
                <UploadCloud className="w-10 h-10 text-slate-400 group-hover:text-[#AA7C11] transition-colors" />
              </div>
              
              <h3 className="text-lg font-black text-slate-800 tracking-tight mb-2">اسحب وأفلت ملف الـ Excel هنا للتحليل الفوري بالذكاء الاصطناعي</h3>
              <p className="text-xs font-bold text-slate-400 leading-normal mb-8">يدعم ملفات مبيعات "المركزية" اليومية – سيتم استيرادها، تدقيقها، وبدء لوحة التحليل الذكي وتوصيات الـ AI فوراً</p>
              
              <button className="bg-slate-900 text-white font-extrabold text-xs py-4 px-10 rounded-full shadow-lg hover:bg-slate-800 hover:scale-[1.02] active:scale-[0.98] transition-all">
                رفع واستيراد الملف اليومي من جهازك
              </button>
            </div>

            {/* Error Area */}
            {errorMsg && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }} 
                animate={{ opacity: 1, y: 0 }} 
                className="bg-rose-50 border border-rose-100/80 text-rose-600 rounded-2xl p-4 flex items-start gap-3 justify-center"
              >
                <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
                <p className="text-sm font-semibold leading-normal">{errorMsg}</p>
              </motion.div>
            )}

            {/* Quick Demo Access with Al-Markazia Branding */}
            <div className="bg-white rounded-3xl p-6 border border-slate-200/60 text-center space-y-4">
              <span className="text-xs text-slate-400 font-extrabold max-w-md mx-auto block leading-relaxed">
                هل تود تجربة النظام واستعراض التقارير والرسوم البيانية للمركزية فوراً دون تحميل ملف خارجي حالياً؟
              </span>
              <button 
                onClick={handleDemoClick}
                className="inline-flex items-center gap-2 bg-[#AA7C11]/10 border border-[#AA7C11]/20 hover:bg-[#AA7C11]/15 text-[#AA7C11] font-black text-xs py-3 px-8 rounded-full transition-all"
              >
                <PlayCircle className="w-4 h-4" />
                <span>تحميل وتصفح بيانات المركزية النموذجية فوراً</span>
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
