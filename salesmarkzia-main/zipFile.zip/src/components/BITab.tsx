import React from "react";
import { DashboardData } from "../types";
import { formatCurrency, formatPercent } from "../lib/utils";
import { Users, Filter, BarChart3, AlertTriangle, Star, CheckCircle2, Award, ArrowUpRight, Sparkles } from "lucide-react";
import { ComposedChart, Bar, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { motion } from "motion/react";

export function BITab({ data }: { data: DashboardData }) {
  const { bi } = data;

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: { staggerChildren: 0.08 }
    }
  };

  const item = {
    hidden: { opacity: 0, scale: 0.98, y: 15 },
    show: { opacity: 1, scale: 1, y: 0, transition: { type: "spring" as const, stiffness: 260, damping: 22 } }
  };

  return (
    <motion.div variants={container} initial="hidden" animate="show" className="space-y-8 select-none font-sans">
      
      {/* Visual Header / Premium Overview */}
      <motion.div variants={item} className="p-8 rounded-[2.5rem] bg-gradient-to-r from-slate-900 via-[#1e140d] to-slate-900 border border-[#c76f00]/30 shadow-2xl relative overflow-hidden group">
        <div className="absolute right-0 top-0 w-48 h-48 bg-amber-500/10 rounded-full blur-3xl pointer-events-none"></div>
        
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-1.5 bg-amber-500/10 border border-[#c76f00]/40 text-amber-500 px-3 py-1 rounded-full text-[10px] font-black tracking-widest uppercase">
              <Sparkles className="w-3 h-3" />
              <span>مصفوفة التحليل المتقدم للمبيعات (BI)</span>
            </div>
            <h2 className="text-xl md:text-2xl font-black text-white leading-tight">باريتو والتصنيف الثلاثي للأعمدة التشغيليّة</h2>
            <p className="text-slate-400 text-xs font-bold max-w-2xl leading-relaxed">
              تصفية السجل الميداني إلى مستويات (A, B, C) لتحديد الأصناف والأقسام التي تغطي 80% من مبيعات الفروع الإجمالية. يضمن هذا النهج تخصيص الموارد التسويقية بشكل عالي الدقة.
            </p>
          </div>
          
          <div className="bg-white/5 border border-white/10 px-5 py-3.5 rounded-2xl flex-shrink-0">
             <span className="text-[10px] text-slate-400 font-bold block">مجموع عينات الدراسة</span>
             <span className="text-base font-black text-white mt-1 block">{bi.pareto.length} قسماً وخطاً ماليّاً</span>
          </div>
        </div>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        {/* Pareto Chart */}
        <motion.div variants={item} className="bg-white rounded-[2.5rem] p-8 shadow-sm border border-slate-200/60 col-span-1 lg:col-span-2 relative overflow-hidden group hover:border-[#c76f00]/30 hover:shadow-md transition-all">
          <div className="absolute -left-10 -bottom-10 w-40 h-40 bg-zinc-100/40 rounded-full blur-3xl pointer-events-none"></div>
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8 relative z-10">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-amber-50 text-[#c76f00] flex items-center justify-center border border-amber-100">
                <BarChart3 className="w-5 h-5 animate-pulse" />
              </div>
              <div>
                <h3 className="text-base font-black text-slate-900 tracking-tight">منحنى باريتو التراكمي للمبيعات (80/20)</h3>
                <p className="text-xs text-slate-400 font-bold mt-1">تحديد الأصناف والأقسام الأهم لتوليد الإيرادات والمبيعات للمركزية</p>
              </div>
            </div>
            <div className="px-4 py-2 bg-amber-500/10 text-[#c76f00] border border-amber-500/20 rounded-full flex items-center gap-2 shadow-sm self-start sm:self-auto">
              <AlertTriangle className="w-4 h-4 animate-bounce" />
              <span className="text-[10px] font-black tracking-wide">نسبة التركيز لـ 80% من المبيعات</span>
            </div>
          </div>
          
          <div className="h-80 relative z-10 w-full font-sans">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={bi.pareto} margin={{ top: 20, right: 10, bottom: 20, left: 10 }}>
                <defs>
                   <linearGradient id="paretoBarGold" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#c76f00" stopOpacity={0.95}/>
                      <stop offset="95%" stopColor="#e8a030" stopOpacity={0.7}/>
                   </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#F1F5F9" />
                <XAxis dataKey="productName" tick={{ fill: "#64748b", fontSize: 11, fontWeight: "700" }} axisLine={false} tickLine={false} dy={10} />
                <YAxis yAxisId="left" tickFormatter={(val) => `${val / 1000}k`} tick={{ fill: "#64748b", fontSize: 11, fontWeight: "700" }} axisLine={false} tickLine={false} dx={-10} />
                <YAxis yAxisId="right" orientation="right" tickFormatter={(val) => `${val * 100}%`} tick={{ fill: "#64748b", fontSize: 11, fontWeight: "700" }} axisLine={false} tickLine={false} dx={10} />
                <Tooltip 
                  contentStyle={{ borderRadius: "20px", border: "1px solid #f1f5f9", boxShadow: "0 10px 15px -3px rgb(0 0 0 / 0.05)", padding: "12px 16px" }}
                  formatter={(value: any, name: string) => {
                     if (name === "التراكمي") return [formatPercent(value), "الوزن التراكمي"];
                     return [formatCurrency(value), "المبيعات الإفرادية"];
                  }}
                />
                <Bar yAxisId="left" dataKey="value" fill="url(#paretoBarGold)" radius={[6, 6, 0, 0]} name="المبيعات" barSize={36} />
                <Line yAxisId="right" type="monotone" dataKey="cumulativeShare" stroke="#c76f00" strokeWidth={4} dot={{ r: 5, fill: "#fff", strokeWidth: 2, stroke: "#c76f00" }} activeDot={{ r: 7 }} name="التراكمي" />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        {/* ABC Classification */}
        <motion.div variants={item} className="bg-white rounded-[2.5rem] p-8 shadow-sm border border-slate-200/60 hover:border-amber-100 hover:shadow-md transition-all">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-10 h-10 rounded-2xl bg-amber-50 text-[#c76f00] flex items-center justify-center border border-amber-100">
              <Filter className="w-5 h-5" />
            </div>
            <div>
               <h3 className="text-base font-black text-slate-900 tracking-tight">تصنيف الأهمية التشغيلية (ABC Matrix)</h3>
               <p className="text-xs text-slate-400 font-bold mt-1">تفريغ الأقسام للأوزان لتجنب نفاد المخزون وإدارة الخطوط</p>
            </div>
          </div>
          
          <div className="space-y-4">
            {/* Category A */}
            <div className="flex bg-slate-50/50 rounded-2xl p-4 border border-indigo-100/50 hover:bg-white hover:shadow-lg hover:shadow-amber-500/[0.01] transition-all">
              <div className="w-16 flex flex-col items-center justify-center border-l border-slate-200/50 ml-1">
                <span className="text-2xl font-black text-[#c76f00]">A</span>
                <span className="text-[10px] font-black text-[#c76f00] bg-amber-50 px-2.5 py-1 rounded-md mt-1 tracking-widest leading-none">الأهم</span>
              </div>
              <div className="flex-1 px-5 flex flex-wrap gap-2 items-center">
                {bi.abc.filter(p => p.category === "A").slice(0, 4).map(p => (
                  <span key={p.productName} className="text-xs font-black text-slate-700 bg-white border border-amber-100 px-3 py-2 rounded-xl shadow-xs inline-flex items-center gap-1.5 hover:border-[#c76f00] transition-colors">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#c76f00]"></span>
                    {p.productName}
                  </span>
                ))}
              </div>
            </div>
            
            {/* Category B */}
            <div className="flex bg-slate-50/50 rounded-2xl p-4 border border-teal-100/50 hover:bg-white hover:shadow-lg hover:shadow-amber-500/[0.01] transition-all">
              <div className="w-16 flex flex-col items-center justify-center border-l border-slate-200/50 ml-1">
                <span className="text-2xl font-black text-teal-600">B</span>
                <span className="text-[10px] font-black text-teal-600 bg-teal-50 px-2.5 py-1 rounded-md mt-1 tracking-widest leading-none">متوسط</span>
              </div>
              <div className="flex-1 px-5 flex flex-wrap gap-2 items-center">
                {bi.abc.filter(p => p.category === "B").length > 0 ? (
                  bi.abc.filter(p => p.category === "B").slice(0, 3).map(p => (
                    <span key={p.productName} className="text-xs font-black text-slate-600 bg-white border border-teal-100 px-3 py-2 rounded-xl shadow-xs inline-flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-teal-500"></span>
                      {p.productName}
                    </span>
                  ))
                ) : (
                  <span className="text-xs text-slate-400 font-bold">لا يوجد ضمن العينات المفلترة</span>
                )}
              </div>
            </div>

            {/* Category C */}
            <div className="flex bg-slate-50/50 rounded-2xl p-4 border border-slate-200/50 hover:bg-white hover:shadow-lg hover:shadow-amber-500/[0.01] transition-all">
              <div className="w-16 flex flex-col items-center justify-center border-l border-slate-200/50 ml-1">
                <span className="text-2xl font-black text-slate-400">C</span>
                <span className="text-[10px] font-black text-slate-500 bg-slate-100 px-2.5 py-1 rounded-md mt-1 tracking-widest leading-none">ثانوي</span>
              </div>
              <div className="flex-1 px-5 flex flex-wrap gap-2 items-center">
                {bi.abc.filter(p => p.category === "C").length > 0 ? (
                  bi.abc.filter(p => p.category === "C").slice(0, 3).map(p => (
                    <span key={p.productName} className="text-xs font-black text-slate-500 bg-white border border-slate-200 px-3 py-2 rounded-xl shadow-xs inline-flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-slate-400"></span>
                      {p.productName}
                    </span>
                  ))
                ) : (
                  <span className="text-xs text-slate-400 font-bold">لا يوجد ضمن العينات المفلترة</span>
                )}
              </div>
            </div>
          </div>
        </motion.div>

        {/* Segments Breakdown */}
        <motion.div variants={item} className="bg-white rounded-[2.5rem] p-8 shadow-sm border border-slate-200/60 hover:border-amber-100 hover:shadow-md transition-all">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-10 h-10 rounded-2xl bg-amber-50 text-[#c76f00] flex items-center justify-center border border-amber-100">
              <Users className="w-5 h-5 animate-pulse" />
            </div>
            <div>
               <h3 className="text-base font-black text-slate-900 tracking-tight">توزيع المبيعات بحسب سلوك وقنوات المستهلكين</h3>
               <p className="text-xs text-slate-400 font-bold mt-1">المساهمة الحقيقية لأنواع طلبات الصالة أونلاين ودليفري بمقارنة الكاش</p>
            </div>
          </div>
          
          <div className="space-y-4">
            {bi.customerSegments.map(segment => (
              <div key={segment.segment} className="relative bg-slate-50/50 rounded-2xl p-4 overflow-hidden border border-slate-100">
                <div 
                  className="absolute left-0 top-0 bottom-0 bg-[#c76f00]/5 -z-0 rounded-l-2xl"
                  style={{ width: `${segment.percentage * 100}%` }}
                ></div>
                <div className="relative z-10 flex justify-between items-center">
                  <span className="text-xs font-black text-slate-705 flex items-center gap-2">
                     <CheckCircle2 className="w-4.5 h-4.5 text-[#c76f00]" />
                     {segment.segment}
                  </span>
                  <div className="text-left font-sans flex items-center gap-4">
                    <div>
                      <p className="text-black text-base font-black mb-0.5">{formatPercent(segment.percentage)}</p>
                      <p className="text-[10px] text-[#c76f00] font-black tracking-wide">{formatCurrency(segment.value)}</p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Contribution Matrix Table */}
        <motion.div variants={item} className="bg-white rounded-[2.5rem] p-8 shadow-sm border border-slate-200/60 lg:col-span-2 overflow-hidden hover:border-[#c76f00]/30 transition-all">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-10 h-10 rounded-2xl bg-amber-50 text-[#c76f00] flex items-center justify-center border border-amber-100">
              <BarChart3 className="w-5 h-5" />
            </div>
            <div>
               <h3 className="text-base font-black text-slate-900 tracking-tight">مصفوفة توزيع الأقسام مبيعاتياً (الجاردنز مقابل خلدا)</h3>
               <p className="text-xs text-slate-400 font-bold mt-1">تحديد مدى كفاءة الأقسام والخطوط التشغيلية بين الفرعين الميدانيين</p>
            </div>
          </div>

          <div className="overflow-x-auto rounded-[1.5rem] border border-slate-150">
            <table className="w-full text-sm text-right">
              <thead className="text-[11px] bg-slate-900 text-white font-black border-none uppercase">
                <tr>
                  <th className="px-6 py-4">القسم والخط التشغيلي</th>
                  <th className="px-6 py-4 text-center">فرع الجاردنز (G)</th>
                  <th className="px-6 py-4 text-center">فرع خلدا (K)</th>
                  <th className="px-6 py-4 text-center">الإجمالي الكلي</th>
                  <th className="px-6 py-4 text-center">المساهمة النسبية</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {data.operational.matrix ? data.operational.matrix.map((row) => (
                  <tr key={row.department} className="hover:bg-slate-50/60 transition-colors">
                    <td className="px-6 py-4 font-black text-slate-800">{row.department}</td>
                    <td className="px-6 py-4 text-center text-slate-600 font-extrabold">{formatCurrency(row.branchG)}</td>
                    <td className="px-6 py-4 text-center text-slate-600 font-extrabold">{formatCurrency(row.branchK)}</td>
                    <td className="px-6 py-4 text-center font-black text-[#c76f00]">{formatCurrency(row.total)}</td>
                    <td className="px-6 py-4 text-center">
                      <div className="flex items-center gap-3 justify-center">
                        <div className="w-20 bg-slate-100 h-2 rounded-full overflow-hidden">
                          <div className="bg-gradient-to-r from-[#c76f00] to-amber-500 h-full rounded-full" style={{ width: `${row.percentage * 100}%` }}></div>
                        </div>
                        <span className="text-[10px] font-black text-slate-500">{formatPercent(row.percentage)}</span>
                      </div>
                    </td>
                  </tr>
                )) : null}
              </tbody>
            </table>
          </div>
        </motion.div>

        {/* Top 10 Departments (Cards instead of simple table) */}
        <motion.div variants={item} className="bg-white rounded-[2.5rem] p-8 shadow-sm border border-slate-200/60 lg:col-span-2">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-amber-50 text-[#c76f00] flex items-center justify-center border border-amber-100">
                <Star className="w-5 h-5 fill-amber-500 text-amber-500" />
              </div>
              <div>
                 <h3 className="text-base font-black text-slate-900 tracking-tight">ترتيب الإيراد لأنجح فئات مبيعات التقرير</h3>
                 <p className="text-xs text-slate-400 font-bold mt-1">تفريغ الأداء للمراكز الأولى ذات القوة الجاذبة للسيولة</p>
              </div>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                {bi.top10Products.map((prod, idx) => {
                   const borderFocus = idx === 0 ? "border-[#c76f00] bg-amber-50/10" : "border-slate-100 bg-slate-50/50";
                   const numColor = idx === 0 ? "bg-[#c76f00] text-white" : "bg-white text-slate-450";
                   return (
                      <div key={prod.name} className={`rounded-2xl p-5 border ${borderFocus} flex items-center gap-4 hover:bg-white hover:border-amber-200 hover:shadow-xl hover:shadow-amber-500/[0.01] transition-all group`}>
                         <div className={`w-11 h-11 ${numColor} rounded-xl shadow-xs border border-slate-100 flex items-center justify-center font-black text-sm group-hover:scale-105 transition-all`}>
                            {idx + 1}
                         </div>
                         <div className="flex-1 min-w-0">
                            <h4 className="font-extrabold text-slate-800 text-sm mb-1 truncate" title={prod.name}>{prod.name}</h4>
                            <div className="flex items-center gap-3">
                               <span className="font-black text-xs text-[#c76f00]" dir="rtl">{formatCurrency(prod.value)}</span>
                               <span className="text-slate-400 text-[10px] font-black bg-slate-100 px-1.5 py-0.5 rounded">{formatPercent(prod.share)}</span>
                            </div>
                         </div>
                      </div>
                   );
                })}
          </div>
        </motion.div>

      </div>
    </motion.div>
  );
}
