import React from "react";
import { DashboardData } from "../types";
import { BrainCircuit, Zap, Target, ArrowRight, Lightbulb, AlertTriangle, TrendingUp, Sparkles, Wand2 } from "lucide-react";
import { motion } from "motion/react";

export function AITab({ data }: { data: DashboardData }) {
  const { ai } = data;

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: { staggerChildren: 0.08 }
    }
  };

  const item = {
    hidden: { opacity: 0, scale: 0.98, y: 15 },
    show: { opacity: 1, scale: 1, y: 0, transition: { type: "spring" as const, stiffness: 260, damping: 22 } }
  };

  return (
    <div className="space-y-8 select-none font-sans">
      <motion.div variants={container} initial="hidden" animate="show" className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Core AI Insights - Full Width Banner */}
        <motion.div variants={item} className="col-span-1 lg:col-span-3 bg-gradient-to-r from-slate-950 via-[#1b120a] to-slate-900 rounded-[2.5rem] p-8 md:p-10 text-white shadow-2xl relative overflow-hidden border border-[#c76f00]/30 group">
          {/* Decorative glowing background mesh */}
          <div className="absolute right-0 top-0 w-80 h-80 bg-gradient-to-br from-[#c76f00]/10 to-transparent rounded-full blur-3xl pointer-events-none"></div>
          
          <div className="absolute top-0 right-10 p-4 opacity-15 pointer-events-none group-hover:scale-105 transition-transform duration-700">
             <BrainCircuit className="w-48 h-48 text-amber-500" />
          </div>
          
          <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-6 border-b border-white/10 pb-6">
            <div className="space-y-1.5">
              <h3 className="text-xl md:text-2xl font-black flex items-center gap-3 tracking-tight">
                <div className="bg-[#c76f00]/20 p-2.5 rounded-xl border border-[#c76f00]/30 text-amber-500">
                  <Wand2 className="w-5 h-5" />
                </div>
                توصيات الذكاء الاصطناعي للمركزية
              </h3>
              <p className="text-slate-400 text-xs font-bold">تحديد فوري لاختناقات أداء الصالة وسلوك المستهلك اليومي</p>
            </div>
            
            <div className="px-4 py-2 bg-amber-500/10 border border-[#c76f00]/30 rounded-full flex items-center gap-2">
              <span className="w-2 h-2 bg-emerald-400 rounded-full animate-ping"></span>
              <span className="text-[10px] font-black text-amber-400 uppercase tracking-widest">تفاعلي ونشط</span>
            </div>
          </div>
          
          <div className="relative z-10 grid grid-cols-1 md:grid-cols-4 gap-6">
            
            {/* Box 1: What Happened */}
            <div className="space-y-3 bg-white/5 p-6 rounded-3xl border border-white/10 backdrop-blur-md hover:bg-white/[0.08] transition-all">
              <h4 className="text-amber-400 font-extrabold text-xs uppercase tracking-wider flex items-center gap-2">
                <Zap className="w-4 h-4 text-amber-500 fill-amber-500/20" /> 
                ماذا حدث؟
              </h4>
              <p className="text-xs md:text-sm font-semibold leading-relaxed text-slate-100">{ai.whatHappened}</p>
            </div>
            
            {/* Box 2: Why Happened */}
            <div className="space-y-3 bg-white/5 p-6 rounded-3xl border border-white/10 backdrop-blur-md hover:bg-white/[0.08] transition-all">
              <h4 className="text-amber-400 font-extrabold text-xs uppercase tracking-wider flex items-center gap-2">
                <Target className="w-4 h-4 text-amber-500 fill-amber-500/20" /> 
                لماذا حدث؟
              </h4>
              <p className="text-xs md:text-sm font-semibold leading-relaxed text-slate-100">{ai.whyHappened}</p>
            </div>
            
            {/* Box 3: What's next */}
            <div className="space-y-3 bg-white/5 p-6 rounded-3xl border border-white/10 backdrop-blur-md hover:bg-white/[0.08] transition-all">
              <h4 className="text-amber-400 font-extrabold text-xs uppercase tracking-wider flex items-center gap-2">
                <ArrowRight className="w-4 h-4 text-amber-500" /> 
                المتوقع لاحقاً؟
              </h4>
              <p className="text-xs md:text-sm font-semibold leading-relaxed text-slate-100">{ai.expectedNext}</p>
            </div>
            
            {/* Box 4: Strategy */}
            <div className="space-y-3 bg-gradient-to-b from-[#c76f00]/30 to-[#a15a00]/30 p-6 rounded-3xl border border-amber-500/30 backdrop-blur-md relative overflow-hidden group">
              <div className="absolute inset-0 bg-[#c76f00]/5 transform group-hover:scale-105 transition-transform duration-500"></div>
              <h4 className="text-white font-extrabold text-xs uppercase tracking-wider flex items-center gap-2 relative z-10 mb-2">
                🤖 الإجراء الموجه:
              </h4>
              <p className="text-xs md:text-sm font-extrabold leading-relaxed text-amber-200 relative z-10 drop-shadow-md">{ai.recommendation}</p>
            </div>

          </div>
        </motion.div>

        {/* Top Opportunities */}
        <motion.div variants={item} className="bg-white rounded-[2.5rem] p-8 border border-slate-200/60 shadow-sm flex flex-col h-full hover:border-amber-100 hover:shadow-md transition-all">
          <div className="flex items-center gap-3 mb-6 border-b border-slate-50 pb-4">
            <div className="bg-[#f0fdf4] text-emerald-600 p-3 rounded-2xl border border-emerald-150">
              <TrendingUp className="w-5 h-5" />
            </div>
            <div>
               <h3 className="text-sm font-black tracking-tight text-slate-900 leading-none">أهم الفرص السانحة</h3>
               <p className="text-[10px] text-slate-405 font-bold mt-1.5 leading-none">مكاسب سريعة لتطوير المبيعات وتجربة الزبائن</p>
            </div>
          </div>
          <div className="flex-1 space-y-4">
            {ai.topOpportunities.map((opp, i) => (
              <div key={i} className="bg-emerald-50/40 p-5 rounded-2xl border border-emerald-100/50 flex items-start gap-4 hover:border-emerald-300 transition-colors">
                <span className="text-emerald-600 font-extrabold text-xs bg-emerald-100 w-6 h-6 flex-shrink-0 flex justify-center items-center rounded-lg mt-0.5">{i+1}</span>
                <p className="text-xs font-bold text-slate-800 leading-relaxed pt-0.5">{opp}</p>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Top Risks */}
        <motion.div variants={item} className="bg-white rounded-[2.5rem] p-8 border border-slate-200/60 shadow-sm flex flex-col h-full hover:border-amber-100 hover:shadow-md transition-all">
          <div className="flex items-center gap-3 mb-6 border-b border-slate-50 pb-4">
            <div className="bg-rose-50 text-rose-600 p-3 rounded-2xl border border-rose-100">
               <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
               <h3 className="text-sm font-black tracking-tight text-slate-900 leading-none">المخاطر والمهددات المحتملة</h3>
               <p className="text-[10px] text-slate-405 font-bold mt-1.5 leading-none">ملفات التحقق والمخاطر الواجب تلافيها فوراً</p>
            </div>
          </div>
          <div className="flex-1 space-y-4">
            {ai.topRisks.map((risk, i) => (
              <div key={i} className="bg-rose-50/40 p-5 rounded-2xl border border-rose-100/50 flex items-start gap-4 hover:border-rose-300 transition-colors">
                <span className="text-rose-600 font-extrabold text-xs bg-rose-100 w-6 h-6 flex-shrink-0 flex justify-center items-center rounded-lg mt-0.5">{i+1}</span>
                <p className="text-xs font-bold text-slate-800 leading-relaxed pt-0.5">{risk}</p>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Revenue Boosts */}
        <motion.div variants={item} className="bg-white rounded-[2.5rem] p-8 shadow-sm border border-slate-200/60 hover:border-amber-100 hover:shadow-md transition-all">
          <div className="flex items-center gap-3 mb-6 border-b border-slate-50 pb-4">
            <div className="bg-amber-50 text-amber-500 p-3 rounded-2xl border border-amber-100">
               <Lightbulb className="w-5 h-5 fill-amber-500/10 text-[#c76f00]" />
            </div>
            <div>
               <h3 className="text-sm font-black tracking-tight text-slate-900 leading-none">أفكار تعظيم ومضاعفة حجم المبيعات</h3>
               <p className="text-[10px] text-slate-405 font-bold mt-1.5 leading-none">البيع المتبادل وشراكات التوصيل السريع</p>
            </div>
          </div>
          <div className="space-y-4">
            {ai.revenueBoosts.map((boost, i) => (
              <div key={i} className="flex items-start gap-4 p-5 rounded-2xl bg-amber-50/20 border border-amber-100/40 hover:border-amber-300 transition-all">
                <div className="w-2 h-2 bg-amber-400 rounded-full mt-2 flex-shrink-0 shadow-[0_0_8px_rgba(251,191,36,0.85)]"></div>
                <p className="text-slate-800 text-xs font-bold leading-relaxed">{boost}</p>
              </div>
            ))}
          </div>
        </motion.div>

      </motion.div>
    </div>
  );
}
