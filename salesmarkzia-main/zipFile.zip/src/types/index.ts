export interface SaleRecord {
  id: string; // unique Row Index
  day: string; // Mon, Tue, etc.
  dayAr: string; // الاثنين، الثلاثاء، الخ.
  cat: string; // R, A, O
  catAr: string; // مطعم، تطبيقات، أخرى
  date: string; // 2026/06/01
  branch: string; // G, K, X
  branchAr: string; // الجاردنز، خلدا، أخرى
  cashier: string; // rami, haya, mohd, ...
  cashierAr: string; // رامي شديد، هيا قلاب، الخ.
  dept: string; // mlh, ln, ...
  deptAr: string; // قسم الملحمة، قسم المشاوي، الخ.
  visa: number;
  cash: number;
  klik: number;
  orders: number;
  cream: number;
  ashyaei: number;
  callcenter: number;
  other: number;
  total: number;
  sheetName?: string;
}

export interface KPIStats {
  totalSales: number;
  netSales: number;
  invoiceCount: number; // Represents total record entries or unique cashier sessions
  avgInvoiceValue: number;
  maxInvoice: number;
  minInvoice: number;
  totalQuantity: number; // Represent sum of transactions or record count
  growthRate: number;
  monthlyGrowthRate: number;
  bestDay: string;
  worstDay: string;
  bestMonth: string;
  worstMonth: string;
  digitalPaymentRatio: number; // Percentage of electronic/digital/app payments vs cash
  attachmentRate: number; // Percentage score of section cross-selling and side items attachment
  peakShifts: { name: string; value: number; share: number; count: number; color: string }[];
  electronicSalesTotal: number;
  cashSalesTotal: number;
  deliverySalesTotal: number;
  directStoreSalesTotal: number;
  paymentFragmentationIndex: number;
  avgInvoiceValueG: number;
  avgInvoiceValueK: number;
}

export interface OperationalStats {
  byBranch: { name: string; value: number; share: number; growth: number }[];
  byDepartment: { name: string; value: number; share: number }[];
  bySalesperson: { name: string; value: number; invoices: number }[]; // Represents Cashier performances
  byChannel: { name: string; value: number; share: number }[];
  byPaymentMethod: { name: string; value: number; share: number }[];
  matrix: {
    department: string;
    branchG: number;
    branchK: number;
    total: number;
    percentage: number;
  }[];
}

export interface BIStats {
  pareto: { productName: string; value: number; cumulativeShare: number; isCritical: boolean }[];
  abc: { productName: string; category: "A" | "B" | "C"; value: number }[];
  top10Products: { name: string; value: number; share: number; quantity: number }[]; // Can represent top departments
  customerSegments: { segment: string; value: number; percentage: number }[];
  productIntelligence: {
    rising: string[];
    falling: string[];
    stagnant: string[];
  };
  branchIntelligence: {
    fastestGrowing: string;
    declining: string;
    stable: string;
    atRisk: string;
  };
}

export interface AIInsights {
  whatHappened: string;
  whyHappened: string;
  expectedNext: string;
  recommendation: string;
  topOpportunities: string[];
  topRisks: string[];
  revenueBoosts: string[];
}

export interface DataQualityReport {
  score: number;
  totalRows: number;
  missingValues: number;
  duplicates: number;
  potentialErrors: number;
  issues: string[];
  sheetsProcessed?: { name: string; rows: number }[];
}

export interface DashboardData {
  kpis: KPIStats;
  operational: OperationalStats;
  bi: BIStats;
  ai: AIInsights;
  quality: DataQualityReport;
}
