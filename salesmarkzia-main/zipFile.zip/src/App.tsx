import React, { useState, useEffect } from "react";
import { analyzeData } from "./lib/analyzer";
import { DashboardData, SaleRecord } from "./types";
import { Layout } from "./components/Layout";
import { FileUpload } from "./components/FileUpload";
import { getDummyData } from "./lib/dummyData";

export default function App() {
  const [records, setRecords] = useState<SaleRecord[]>(() => []);
  const [scenario, setScenario] = useState<number>(1);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  
  // Custom AI summary state cache to prevent resetting on filter transitions
  const [cachedAiInsights, setCachedAiInsights] = useState<any>(null);

  // Filter States
  const [filterBranch, setFilterBranch] = useState("");
  const [filterCat, setFilterCat] = useState("");
  const [filterDept, setFilterDept] = useState("");
  const [filterCashier, setFilterCashier] = useState("");
  const [filterDay, setFilterDay] = useState("");
  const [filterMonth, setFilterMonth] = useState("");

  const handleFileUpload = async (processedData: SaleRecord[]) => {
    setIsAnalyzing(true);
    
    if (!processedData || processedData.length === 0) {
      console.error("لم يتم العثور على أية مبيعات في الملف.");
      setIsAnalyzing(false);
      return;
    }

    try {
      // Clear filters upon new file uploads to prevent confusing empty states
      setFilterBranch("");
      setFilterCat("");
      setFilterDept("");
      setFilterCashier("");
      setFilterDay("");
      setFilterMonth("");
      setScenario(1);

      setRecords(processedData);

      // Fetch cloud deep intelligence insights
      try {
        const tempAnalyzed = analyzeData(processedData, 1);
        const summaryData = {
           totalSales: tempAnalyzed.kpis.totalSales,
           growthRate: tempAnalyzed.kpis.growthRate,
           invoiceCount: tempAnalyzed.kpis.invoiceCount,
           topBranches: tempAnalyzed.operational.byBranch.slice(0, 3).map(b => ({ name: b.name, value: b.value })),
           topProducts: tempAnalyzed.bi.top10Products.slice(0, 5).map(p => ({ name: p.name, share: p.share }))
        };

        const response = await fetch('/api/analyze', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ summaryData })
        });
        
        if (response.ok) {
          const aiData = await response.json();
          setCachedAiInsights(aiData);
        } else {
          setCachedAiInsights(null);
        }
      } catch(err) {
        console.error("AI cloud analysis connection missed, falling back to instant local intelligence.", err);
        setCachedAiInsights(null);
      }
      
    } catch (err) {
      console.error("تعذر ترحيل وتنظيم البيانات.", err);
    }
    
    setIsAnalyzing(false);
  };

  // Live element update callback
  const handleUpdateRecord = (id: string, field: keyof SaleRecord, value: number) => {
    setRecords((prev) => {
      return prev.map((r) => {
        if (r.id === id) {
          const numVal = Number(value) || 0;
          const updatedRow = { ...r, [field]: numVal };
          
          // Recompute row total
          updatedRow.total = 
            (Number(updatedRow.visa) || 0) +
            (Number(updatedRow.cash) || 0) +
            (Number(updatedRow.klik) || 0) +
            (Number(updatedRow.orders) || 0) +
            (Number(updatedRow.cream) || 0) +
            (Number(updatedRow.ashyaei) || 0) +
            (Number(updatedRow.callcenter) || 0) +
            (Number(updatedRow.other) || 0);

          return updatedRow;
        }
        return r;
      });
    });
  };

  const handleResetSession = () => {
    setRecords([]);
    setCachedAiInsights(null);
    setFilterBranch("");
    setFilterCat("");
    setFilterDept("");
    setFilterCashier("");
    setFilterDay("");
    setFilterMonth("");
    setScenario(1);
  };

  // Multi-dimensional filters filtering step
  const filteredRecords = records.filter((r) => {
    let matchesMonth = true;
    if (filterMonth) {
      const d = new Date(r.date);
      const mStr = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
      matchesMonth = (mStr === filterMonth);
    }
    return (
      (!filterBranch || r.branch === filterBranch) &&
      (!filterCat || r.cat === filterCat) &&
      (!filterDept || r.deptAr === filterDept) &&
      (!filterCashier || r.cashierAr === filterCashier) &&
      (!filterDay || r.day === filterDay) &&
      matchesMonth
    );
  });

  // Calculate final dashboard specifications
  let data: DashboardData | null = null;
  if (records.length > 0) {
    try {
      const hasActiveFilter = !!(filterBranch || filterCat || filterDept || filterCashier || filterDay || filterMonth);
      const analysisInput = hasActiveFilter ? filteredRecords : records;
      data = analyzeData(analysisInput, scenario);
      if (cachedAiInsights && data) {
        data.ai = { ...data.ai, ...cachedAiInsights };
      }
    } catch (e) {
      console.error("Failing dynamic analytics pass", e);
    }
  }

  // Define unique items lists for populated dropdowns
  const branchOptions = Array.from(new Set(records.map(r => r.branch))).filter(Boolean);
  const catOptions = Array.from(new Set(records.map(r => r.cat))).filter(Boolean);
  const deptOptions = Array.from(new Set(records.map(r => r.deptAr))).filter(Boolean).sort();
  const cashierOptions = Array.from(new Set(records.map(r => r.cashierAr))).filter(Boolean).sort();
  const dayOptions = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].filter(d => records.some(r => r.day === d));

  const monthOptions = Array.from(
    new Set(
      records.map((r) => {
        const d = new Date(r.date);
        if (isNaN(d.getTime())) return "";
        return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
      })
    )
  ).filter(Boolean).sort();

  const filterStates = {
    filterBranch,
    setFilterBranch,
    filterCat,
    setFilterCat,
    filterDept,
    setFilterDept,
    filterCashier,
    setFilterCashier,
    filterDay,
    setFilterDay,
    filterMonth,
    setFilterMonth,
    branchOptions,
    catOptions,
    deptOptions,
    cashierOptions,
    dayOptions,
    monthOptions,
    onClearAll: () => {
      setFilterBranch("");
      setFilterCat("");
      setFilterDept("");
      setFilterCashier("");
      setFilterDay("");
      setFilterMonth("");
    }
  };

  if (!data || isAnalyzing || records.length === 0) {
    return (
      <div dir="rtl" className="h-screen bg-slate-50 text-slate-800 font-sans overflow-hidden">
        <FileUpload onUpload={handleFileUpload} isAnalyzing={isAnalyzing} />
      </div>
    );
  }

  return (
    <div dir="rtl" className="h-screen bg-[#F8FAFC] text-slate-800 font-sans overflow-hidden select-none">
      <Layout 
        data={data} 
        scenario={scenario} 
        setScenario={setScenario} 
        onReset={handleResetSession}
        records={records}
        onUpdateRecord={handleUpdateRecord}
        filterStates={filterStates}
      />
    </div>
  );
}
