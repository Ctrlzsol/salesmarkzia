import React, { useState, useMemo } from "react";
import { DashboardData, SaleRecord } from "../types";
import { analyzeData } from "../lib/analyzer";
import { formatCurrency, formatNumber, formatPercent } from "../lib/utils";
import {
  TrendingUp,
  TrendingDown,
  DollarSign,
  Receipt,
  ShoppingCart,
  Calendar,
  Layers,
  Sparkles,
  Zap,
  Coffee,
  Sun,
  Moon,
  Smartphone,
  Search,
  CheckCircle2,
  ShieldCheck,
  HelpCircle,
  Info,
  Edit2,
  Check,
  ArrowRight,
  RefreshCw,
  Sliders,
  ChevronLeft,
  ChevronRight,
  Database,
  ArrowUpRight,
  ArrowDownRight
} from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, AreaChart, Area, PieChart, Pie, Legend, Brush, ReferenceArea, Line, ComposedChart } from "recharts";
import { motion, AnimatePresence } from "motion/react";

// Premium High-Precision Tooltip for exact daily audits
const CustomTimelineTooltip = ({ active, payload }: any) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    const totalVal = data.total;
    const gVal = data.branchG;
    const kVal = data.branchK;
    const cashVal = data.cash;
    const visaVal = data.visa;
    const klikVal = data.klik;
    const delivVal = data.delivery;
    
    // Parse Arabic date nicely
    const dObj = new Date(data.dateStr);
    const dayNameAr = dObj.toLocaleDateString("ar-JO", { weekday: "long" });
    const formattedDate = dObj.toLocaleDateString("ar-JO", { year: "numeric", month: "long", day: "numeric" });

    // Dynamic currency formatter
    const formatCurrencyLocal = (val: number) => {
       return new Intl.NumberFormat("ar-JO", { style: "currency", currency: "JOD" }).format(val);
    };

    return (
      <div className="bg-slate-900 text-white rounded-2xl p-5 border border-slate-800 shadow-2xl relative max-w-[280px] text-right" dir="rtl">
        <div className="space-y-1 pb-3.5 border-b border-slate-850">
          <span className="text-[10px] text-[#AA7C11] font-black tracking-widest uppercase block">{dayNameAr}</span>
          <h5 className="text-xs font-black text-slate-100">{formattedDate}</h5>
        </div>

        <div className="py-3.5 space-y-2 border-b border-slate-850">
          <div className="flex justify-between items-center text-xs gap-4">
            <span className="text-slate-400 font-bold">إيراد اليوم الكلي:</span>
            <span className="font-sans font-black text-emerald-400 text-sm whitespace-nowrap">{formatCurrencyLocal(totalVal)}</span>
          </div>

          <div className="grid grid-cols-2 gap-2 text-[10px] pt-1">
            <div className="bg-slate-850 p-2 rounded-lg border border-slate-800 text-center">
              <span className="text-amber-400 font-black block">الجاردنز (G)</span>
              <span className="text-slate-100 font-bold font-sans mt-0.5 block whitespace-nowrap">{formatCurrencyLocal(gVal)}</span>
            </div>
            <div className="bg-slate-850 p-2 rounded-lg border border-slate-800 text-center">
              <span className="text-sky-400 font-black block">خلدا (K)</span>
              <span className="text-slate-100 font-bold font-sans mt-0.5 block whitespace-nowrap">{formatCurrencyLocal(kVal)}</span>
            </div>
          </div>
        </div>

        <div className="pt-3.5 space-y-2">
          <span className="text-[9px] text-slate-400 font-black uppercase tracking-wider block">سلة المدفوعات والمسارات تفصيلياً:</span>
          
          <div className="space-y-1.5 text-[10px]">
            <div className="flex justify-between items-center text-slate-350">
              <span>💳 بطاقات البنوك والفيزا:</span>
              <span className="font-sans font-extrabold whitespace-nowrap">{formatCurrencyLocal(visaVal)}</span>
            </div>
            <div className="flex justify-between items-center text-slate-350">
              <span>💵 نقد وكاش بالصالة:</span>
              <span className="font-sans font-extrabold whitespace-nowrap">{formatCurrencyLocal(cashVal)}</span>
            </div>
            <div className="flex justify-between items-center text-slate-350">
              <span>⚡ كليك والتحويل المباشر:</span>
              <span className="font-sans font-extrabold whitespace-nowrap">{formatCurrencyLocal(klikVal)}</span>
            </div>
            <div className="flex justify-between items-center text-slate-350">
              <span>🛵 تطبيقات التوصيل للتواصل:</span>
              <span className="font-sans font-extrabold whitespace-nowrap">{formatCurrencyLocal(delivVal)}</span>
            </div>
          </div>
        </div>
      </div>
    );
  }
  return null;
};

interface OverviewTabProps {
  data: DashboardData;
  records: SaleRecord[];
  onUpdateRecord: (id: string, field: keyof SaleRecord, value: number) => void;
  filterStates?: any;
  scenario?: number;
}

export function OverviewTab({ data, records, onUpdateRecord, filterStates, scenario = 1 }: OverviewTabProps) {
  const { kpis, operational, bi, ai } = data;

  // Internal visual workspace tabs
  const [workspaceTab, setWorkspaceTab] = useState<"payments" | "branches" | "pareto" | "ai" | "monthComparison" | "interactiveTimeline">("payments");

  // Dynamically compute absolute high-precision daily statistics for Recharts chart
  const dailyTimelineData = useMemo(() => {
    const dailyMap: Record<string, { 
      dateStr: string;
      total: number; 
      branchG: number; 
      branchK: number; 
      cash: number; 
      visa: number; 
      klik: number; 
      delivery: number; 
      count: number;
    }> = {};

    records.forEach((r) => {
      if (!r.date) return;
      const key = r.date; 
      if (!dailyMap[key]) {
        dailyMap[key] = {
          dateStr: key,
          total: 0,
          branchG: 0,
          branchK: 0,
          cash: 0,
          visa: 0,
          klik: 0,
          delivery: 0,
          count: 0
        };
      }

      const totalVal = r.total * scenario;
      dailyMap[key].total += totalVal;
      dailyMap[key].count += 1;

      if (r.branch === "G") dailyMap[key].branchG += totalVal;
      if (r.branch === "K") dailyMap[key].branchK += totalVal;

      dailyMap[key].cash += (r.cash || 0) * scenario;
      dailyMap[key].visa += (r.visa || 0) * scenario;
      dailyMap[key].klik += (r.klik || 0) * scenario;
      dailyMap[key].delivery += ((r.orders || 0) + (r.cream || 0) + (r.ashyaei || 0)) * scenario;
    });

    return Object.values(dailyMap).sort((a, b) => a.dateStr.localeCompare(b.dateStr));
  }, [records, scenario]);

  // Zoom state variables for our new High-Dignity Zoom chart
  const [zoomStartIndex, setZoomStartIndex] = useState<number>(0);
  const [zoomEndIndex, setZoomEndIndex] = useState<number>(100);
  const [isZoomActive, setIsZoomActive] = useState<boolean>(false);

  // Sync view indexes when timeline data changes
  const maxIdx = Math.max(0, dailyTimelineData.length - 1);
  const activeZoomStartIndex = isZoomActive ? Math.min(zoomStartIndex, maxIdx) : 0;
  const activeZoomEndIndex = isZoomActive ? Math.min(zoomEndIndex, maxIdx) : maxIdx;

  const zoomedTimelineData = useMemo(() => {
    if (dailyTimelineData.length === 0) return [];
    return dailyTimelineData.slice(activeZoomStartIndex, activeZoomEndIndex + 1);
  }, [dailyTimelineData, activeZoomStartIndex, activeZoomEndIndex]);

  const handleSetZoomShortcut = (type: "all" | "30days" | "7days" | "peak") => {
    const totalDays = dailyTimelineData.length;
    if (totalDays === 0) return;
    
    setIsZoomActive(true);
    if (type === "all") {
      setZoomStartIndex(0);
      setZoomEndIndex(totalDays - 1);
      setIsZoomActive(false); // reset custom zoom
    } else if (type === "30days") {
      setZoomStartIndex(Math.max(0, totalDays - 30));
      setZoomEndIndex(totalDays - 1);
    } else if (type === "7days") {
      setZoomStartIndex(Math.max(0, totalDays - 7));
      setZoomEndIndex(totalDays - 1);
    } else if (type === "peak") {
      let peakIdx = 0;
      let maxSale = 0;
      dailyTimelineData.forEach((day, idx) => {
        if (day.total > maxSale) {
          maxSale = day.total;
          peakIdx = idx;
        }
      });
      setZoomStartIndex(Math.max(0, peakIdx - 3));
      setZoomEndIndex(Math.min(totalDays - 1, peakIdx + 3));
    }
  };

  // Dynamically compute monthly aggregates from 'records' to present an absolute 100% correct history of ALL months loaded in the Excel file!
  const monthlyTimelineData = useMemo(() => {
    const monthlyMap: Record<string, { total: number; invoices: number; branchG: number; branchK: number; cash: number; digital: number; sheetRows: number }> = {};
    records.forEach((r) => {
      const d = new Date(r.date);
      if (isNaN(d.getTime())) return;
      const mKey = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
      
      if (!monthlyMap[mKey]) {
        monthlyMap[mKey] = { total: 0, invoices: 0, branchG: 0, branchK: 0, cash: 0, digital: 0, sheetRows: 0 };
      }
      
      const totalVal = r.total * scenario;
      monthlyMap[mKey].total += totalVal;
      monthlyMap[mKey].invoices += 1;
      monthlyMap[mKey].sheetRows += 1;
      
      if (r.branch === "G") monthlyMap[mKey].branchG += totalVal;
      if (r.branch === "K") monthlyMap[mKey].branchK += totalVal;
      
      monthlyMap[mKey].cash += r.cash * scenario;
      monthlyMap[mKey].digital += (totalVal - r.cash * scenario);
    });
    
    // Convert to list & sort chronologically
    return Object.entries(monthlyMap)
      .map(([monthStr, stats]) => {
        return {
          monthStr,
          ...stats,
          avgTicket: stats.invoices > 0 ? stats.total / stats.invoices : 0,
          digitalPct: stats.total > 0 ? stats.digital / stats.total : 0
        };
      })
      .sort((a, b) => a.monthStr.localeCompare(b.monthStr));
  }, [records, scenario]);

  // Interactive KPI Mathematical Tooltip State
  const [activeKpiTooltip, setActiveKpiTooltip] = useState<string | null>(null);

  // Auditor States
  const [auditSearch, setAuditSearch] = useState("");
  const [auditPage, setAuditPage] = useState(0);
  const [editingRowId, setEditingRowId] = useState<string | null>(null);
  const [rowEditState, setRowEditState] = useState<Partial<SaleRecord>>({});

  const itemsPerPage = 10;

  // Toggle to compare with previous month's performance
  const [comparePrevious, setComparePrevious] = useState(false);

  // Lists of months found in dataset
  const monthOptions = useMemo(() => {
    return Array.from(
      new Set(
        records.map((r) => {
          const d = new Date(r.date);
          if (isNaN(d.getTime())) return "";
          return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
        })
      )
    ).filter(Boolean).sort();
  }, [records]);

  // Active month
  const curMonthStr = useMemo(() => {
    return filterStates?.filterMonth || monthOptions[monthOptions.length - 1] || "";
  }, [filterStates?.filterMonth, monthOptions]);

  // Previous month string
  const prevMonthStr = useMemo(() => {
    if (!curMonthStr) return "";
    const curMonthIndex = monthOptions.indexOf(curMonthStr);
    
    const getPreviousMonth = (yearMonthStr: string): string => {
      if (!yearMonthStr) return "";
      const [year, month] = yearMonthStr.split("-").map(Number);
      if (!year || !month) return "";
      let prevYear = year;
      let prevMonth = month - 1;
      if (prevMonth === 0) {
        prevMonth = 12;
        prevYear = year - 1;
      }
      return `${prevYear}-${String(prevMonth).padStart(2, "0")}`;
    };

    if (curMonthIndex > 0) {
      return monthOptions[curMonthIndex - 1];
    } else {
      return getPreviousMonth(curMonthStr);
    }
  }, [curMonthStr, monthOptions]);

  // Records of the previous month with all other identical filters applied
  const prevMonthRecords = useMemo(() => {
    if (!prevMonthStr) return [];
    return records.filter((r) => {
      const d = new Date(r.date);
      if (isNaN(d.getTime())) return false;
      const mStr = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
      if (mStr !== prevMonthStr) return false;

      // Apply other active filters
      if (filterStates?.filterBranch && r.branch !== filterStates.filterBranch) return false;
      if (filterStates?.filterCat && r.cat !== filterStates.filterCat) return false;
      if (filterStates?.filterDept && r.deptAr !== filterStates.filterDept) return false;
      if (filterStates?.filterCashier && r.cashierAr !== filterStates.filterCashier) return false;
      if (filterStates?.filterDay && r.day !== filterStates.filterDay) return false;

      return true;
    });
  }, [records, prevMonthStr, filterStates]);

  // Previous Month's analyzed KPIs
  const prevData = useMemo(() => {
    if (prevMonthRecords.length === 0) return null;
    try {
      return analyzeData(prevMonthRecords, scenario);
    } catch (e) {
      console.error("Error analyzing previous month's data:", e);
      return null;
    }
  }, [prevMonthRecords, scenario]);

  // Helper to format Arabic month names nicely
  const getMonthNameAr = (yearMonthStr: string): string => {
    if (!yearMonthStr) return "";
    const [yr, mnStr] = yearMonthStr.split("-");
    const mn = parseInt(mnStr, 10);
    const monthsAr = [
      "يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
      "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"
    ];
    const monthName = monthsAr[mn - 1] || mnStr;
    return `${monthName} ${yr}`;
  };

  // Comparison tag renderer
  const renderComparison = (current: number, target: number | undefined, isPercentageField: boolean = false) => {
    if (!comparePrevious) return null;
    const targetMonthName = prevMonthStr ? getMonthNameAr(prevMonthStr) : "الشهر السابق";
    if (target === undefined || target === null || target === 0) {
      return (
        <span className="text-[10px] font-bold text-slate-400 mt-2 flex items-center gap-1 bg-slate-50 border border-slate-100 rounded-lg px-2 py-0.5">
          <span>غير متوفر لـ {targetMonthName}</span>
        </span>
      );
    }

    let diffPercent = 0;
    if (isPercentageField) {
      diffPercent = current - target;
    } else {
      diffPercent = ((current - target) / target) * 100;
    }

    const isPositive = diffPercent >= 0;
    const absPercent = Math.abs(diffPercent).toFixed(1);

    return (
      <div className={`mt-2 flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-[10px] font-black border transition-all ${
        isPositive 
          ? 'bg-emerald-50 text-emerald-700 border-emerald-200/60 shadow-[0_2px_4px_rgba(16,185,129,0.05)]' 
          : 'bg-rose-50 text-rose-700 border-rose-200/60 shadow-[0_2px_4px_rgba(239,68,68,0.05)]'
      } self-start`} dir="rtl">
        {isPositive ? <TrendingUp className="w-3.5 h-3.5 text-emerald-600" /> : <TrendingDown className="w-3.5 h-3.5 text-rose-600" />}
        <span dir="ltr" className="font-sans font-bold">{isPositive ? '+' : '-'}{absPercent}%</span>
        <span className="text-[9px] text-slate-400 font-bold">مقارنة بـ {targetMonthName}</span>
      </div>
    );
  };

  // If no transactions
  if (!kpis || kpis.totalSales === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-20 px-4 text-center rounded-[2.5rem] bg-white border border-slate-200/60 shadow-sm max-w-2xl mx-auto space-y-6 font-sans">
        <div className="w-16 h-16 rounded-full bg-rose-50 flex items-center justify-center text-rose-500 border border-rose-100">
          <Layers className="w-8 h-8" />
        </div>
        <div className="space-y-2">
          <h3 className="text-xl font-black text-slate-900">عفواً، لا توجد سجلات مبيعات تطابق التصفية الحالية</h3>
          <p className="text-sm font-bold text-slate-400 max-w-md mx-auto leading-relaxed">
            لم نتمكن من العثور على أي معاملات ماليّة للمركزية متطابقة مع شروط التصفية المحددة في الأعلى (الفرع، التصنيف، القسم، الكاشير أو يوم الأسبوع).
          </p>
        </div>
        <div className="text-xs bg-slate-50 text-slate-500 px-4 py-2 rounded-xl border border-slate-200">
          نصيحة: حاول الضغط على زر <span className="text-[#c76f00] font-black">"إعادة تعيين وبدء جديد"</span> في شريط التصفية العلوي لاستعادة كل البيانات.
        </div>
      </div>
    );
  }

  // Mathematics live calculations verification directly from state
  const auditSummary = useMemo(() => {
    let cash = 0;
    let visa = 0;
    let cliq = 0;
    let apps = 0; // Talabat, careem, ashyaei, call center, cream
    let other = 0;
    let total = 0;

    records.forEach((r) => {
      cash += Number(r.cash || 0);
      visa += Number(r.visa || 0);
      cliq += Number(r.klik || 0);
      apps += Number(r.orders || 0) + Number(r.cream || 0) + Number(r.ashyaei || 0) + Number(r.callcenter || 0);
      other += Number(r.other || 0);
      total += Number(r.total || 0);
    });

    return { cash, visa, cliq, apps, other, total };
  }, [records]);

  // Auditor list filter
  const filteredAuditRecords = useMemo(() => {
    if (!auditSearch.trim()) return records;
    const s = auditSearch.trim().toLowerCase();
    return records.filter((r) => {
      return (
        String(r.id || "").toLowerCase().includes(s) ||
        String(r.cashierAr || "").toLowerCase().includes(s) ||
        String(r.deptAr || "").toLowerCase().includes(s) ||
        String(r.branchAr || "").toLowerCase().includes(s) ||
        String(r.dayAr || "").toLowerCase().includes(s) ||
        String(r.sheetName || "").toLowerCase().includes(s)
      );
    });
  }, [records, auditSearch]);

  const pageCount = Math.ceil(filteredAuditRecords.length / itemsPerPage);
  const pagedRecords = useMemo(() => {
    const start = auditPage * itemsPerPage;
    return filteredAuditRecords.slice(start, start + itemsPerPage);
  }, [filteredAuditRecords, auditPage]);

  // Handle Edit Action
  const startEdit = (row: SaleRecord) => {
    setEditingRowId(row.id);
    setRowEditState({ ...row });
  };

  const saveEdit = (rowId: string) => {
    const keys: (keyof SaleRecord)[] = ["visa", "cash", "klik", "orders", "cream", "ashyaei", "callcenter", "other"];
    keys.forEach((k) => {
      if (rowEditState[k] !== undefined) {
        onUpdateRecord(rowId, k, Number(rowEditState[k] || 0));
      }
    });
    setEditingRowId(null);
    setRowEditState({});
  };

  const handleEditFieldChange = (key: keyof SaleRecord, val: string) => {
    const num = parseFloat(val);
    setRowEditState((prev) => ({
      ...prev,
      [key]: isNaN(num) ? 0 : num
    }));
  };

  // Payment Breakdown PIE Chart Config
  const pieData = [
    { name: "الدفع النقدي (كاش)", value: auditSummary.cash, color: "#e8a030" },
    { name: "الدفع ببطاقات فيزا", value: auditSummary.visa, color: "#4f46e5" },
    { name: "شبكة كليك البنكية", value: auditSummary.cliq, color: "#10b981" },
    { name: "شركاء التطبيقات (الدليفري)", value: auditSummary.apps, color: "#8b5cf6" },
    { name: "بوابات الدفع الأخرى", value: auditSummary.other, color: "#64748b" }
  ].filter(p => p.value > 0);

  const containerVariants = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: { staggerChildren: 0.05 }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 15 },
    show: { opacity: 1, y: 0, transition: { type: "spring" as const, stiffness: 200, damping: 20 } }
  };

  return (
    <motion.div variants={containerVariants} initial="hidden" animate="show" className="space-y-8 select-none font-sans text-right" dir="rtl">
      
      {/* Top Banner Overview */}
      <motion.div variants={itemVariants} className="relative bg-gradient-to-r from-slate-900 via-[#1b1509] to-slate-900 rounded-[2rem] p-6 md:p-8 border border-amber-500/20 shadow-xl overflow-hidden">
        <div className="absolute right-0 top-0 bottom-0 w-1/3 bg-gradient-to-l from-amber-500/10 to-transparent blur-3xl pointer-events-none rounded-full translate-x-12 -translate-y-12"></div>
        <div className="absolute left-0 bottom-0 w-1/4 bg-indigo-500/5 blur-3xl pointer-events-none rounded-full -translate-x-12 translate-y-12"></div>
        
        <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-2 text-center md:text-right">
            <span className="inline-flex items-center gap-1.5 bg-[#c76f00]/20 border border-[#c76f00]/30 text-amber-500 px-3 py-1 rounded-full text-xs font-black">
              <Sparkles className="w-3.5 h-3.5" />
              <span>لوحة القيادة المكتملة</span>
            </span>
            <h2 className="text-xl md:text-2xl font-black text-white">المركزية – محرك تحليل ومطابقة مبيعات المبيعات والورديات</h2>
            <p className="text-xs text-slate-400 font-medium max-w-2xl leading-relaxed">
              تم تحديث هذا النظام بشكل شامل وجذري ليعطيك قراءة شاملة في شاشة واحدة متكاملة ومنصة ممتازة لمطابقة وتدقيق صحة الإيرادات مقابل المدخلات الفورية في ملف الإكسل.
            </p>
          </div>
          
          <div className="hidden lg:flex items-center gap-3 bg-white/5 border border-white/10 p-4 rounded-2xl">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-500">
              <Zap className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <p className="text-[10px] text-[#e8a030] font-bold">نمو المبيعات</p>
              <h4 className="text-xs font-black text-white">{formatPercent(kpis.growthRate)} سنوي</h4>
              <p className="text-[9px] text-emerald-400" dir="ltr">↑ +{formatPercent(kpis.monthlyGrowthRate)} شهري</p>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Header with Comparison Switch Toggler */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mt-6 bg-white p-5 rounded-3xl border border-slate-200/60 shadow-3xs">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-amber-500/10 text-[#c76f00] flex items-center justify-center border border-amber-200">
            <Sliders className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-black text-slate-800">مقارنة وتحليل الأداء المالي</h3>
            <p className="text-[10px] text-slate-450 font-bold mt-0.5">قارن مبيعات الفلاتر الحالية مع الشهر السابق لرصد نسب النمو والانحراف المالي</p>
          </div>
        </div>

        {/* Dynamic Switch Toggle Button */}
        <div 
          onClick={() => setComparePrevious(!comparePrevious)}
          className="flex items-center gap-3 bg-slate-50 hover:bg-slate-100/70 border border-slate-200/80 p-2 rounded-2xl self-start sm:self-auto cursor-pointer select-none group active:scale-[0.98] transition-all duration-200"
        >
          <span className="text-xs font-black text-slate-650 group-hover:text-[#c76f00] pr-2 transition-colors">مقارنة المؤشرات مع الشهر السابق</span>
          <div className={`w-11 h-6 rounded-full p-0.5 transition-colors duration-300 flex items-center ${comparePrevious ? 'bg-amber-500' : 'bg-slate-300'}`}>
            <div className={`bg-white w-5 h-5 rounded-full shadow-md transform transition-transform duration-300 ${comparePrevious ? 'translate-x-0' : 'translate-x-5'}`}></div>
          </div>
        </div>
      </div>

      {/* Six Main KPIs Row (Unified High Highlights with Interactive Mathematical Tooltips) */}
      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-5">
        
        {/* Total Sales */}
        <motion.div 
          onClick={() => setActiveKpiTooltip(activeKpiTooltip === "totalSales" ? null : "totalSales")}
          variants={itemVariants} 
          className={`bg-white p-6 rounded-2xl border border-slate-205/60 shadow-xs hover:border-[#c76f00] hover:shadow-md transition-all duration-300 relative overflow-hidden flex flex-col justify-between cursor-pointer group ${comparePrevious ? 'min-h-[12.5rem] h-auto pb-5' : 'h-44'}`}
          whileHover={{ y: -4 }}
        >
          {/* Top subtle golden line */}
          <div className="absolute top-0 left-0 right-0 h-[3px] bg-gradient-to-r from-amber-500 to-[#c76f00]"></div>
          {/* Background Decor */}
          <div className="absolute -right-6 -top-6 w-16 h-16 bg-amber-550/5 rounded-full blur-xl pointer-events-none transition-transform group-hover:scale-125"></div>
          
          <div className="flex items-center justify-between mb-3 relative z-10">
            <div className="w-10 h-10 rounded-2xl bg-amber-50 flex items-center justify-center text-[#c76f00] border border-amber-100 shadow-3xs">
              <DollarSign className="w-5 h-5" />
            </div>
            <div className="flex items-center gap-1.5">
              <span className="text-[9px] font-black tracking-normal px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200">نشط</span>
              <button 
                onClick={(e) => { e.stopPropagation(); setActiveKpiTooltip(activeKpiTooltip === "totalSales" ? null : "totalSales"); }} 
                className="text-slate-400 hover:text-[#c76f00] p-1 transition-colors"
                title="اضغط لمشاهدة معادلة الاحتساب ونظام التحقق"
              >
                <HelpCircle className="w-4 h-4 text-amber-500" />
              </button>
            </div>
          </div>
          <div className="relative z-10 flex-1">
            <span className="text-slate-400 text-[11px] font-extrabold block">إجمالي المبيعات</span>
            <span className="text-slate-500 text-[9px] font-bold block leading-tight mt-0.5 whitespace-nowrap">قنوات التحصيل بالدينار الأردني</span>
            <p className="text-xl font-black text-slate-900 mt-1 relative z-10 font-sans tracking-tight">{formatCurrency(kpis.totalSales)}</p>
            {renderComparison(kpis.totalSales, prevData?.kpis.totalSales)}
          </div>

          <AnimatePresence>
            {activeKpiTooltip === "totalSales" && (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="absolute inset-0 bg-slate-950 text-white p-5 flex flex-col justify-between z-20 rounded-2xl border border-slate-800"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-black text-amber-400">صيغة التحقق المالي</span>
                    <button 
                      onClick={() => setActiveKpiTooltip(null)} 
                      className="text-slate-400 hover:text-white text-[9px] bg-slate-900 border border-slate-800 px-2 py-1 rounded-lg"
                    >
                      إغلاق ×
                    </button>
                  </div>
                  <p className="text-[10px] text-slate-350 font-bold leading-relaxed">
                    مجموع كافة مسارات الدفع والتحصيل من الورديات المستخلصة تفصيلياً كاش وفيزا وكليك وتطبيقات.
                  </p>
                </div>
                <div className="bg-slate-900 p-2 rounded-xl border border-slate-800 text-center font-mono text-[9px] text-emerald-400 font-bold" dir="ltr">
                  SUM(Cash + Visa + Klik + Apps + Other)
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>

        {/* average ticket */}
        <motion.div 
          onClick={() => setActiveKpiTooltip(activeKpiTooltip === "avgInvoice" ? null : "avgInvoice")}
          variants={itemVariants} 
          className={`bg-white p-6 rounded-2xl border border-slate-205/60 shadow-xs hover:border-[#c76f00] hover:shadow-md transition-all duration-300 relative overflow-hidden flex flex-col justify-between cursor-pointer group ${comparePrevious ? 'min-h-[12.5rem] h-auto pb-5' : 'h-44'}`}
          whileHover={{ y: -4 }}
        >
          {/* Top subtle indigo line */}
          <div className="absolute top-0 left-0 right-0 h-[3px] bg-gradient-to-r from-indigo-500 to-violet-600"></div>
          {/* Background Decor */}
          <div className="absolute -right-6 -top-6 w-16 h-16 bg-indigo-550/5 rounded-full blur-xl pointer-events-none transition-transform group-hover:scale-125"></div>
          
          <div className="flex items-center justify-between mb-3 relative z-10">
            <div className="w-10 h-10 rounded-2xl bg-indigo-50 flex items-center justify-center text-indigo-650 border border-indigo-100 shadow-3xs">
              <ShoppingCart className="w-5 h-5 text-indigo-600" />
            </div>
            <div className="flex items-center gap-1.5">
              <span className="text-[9px] font-black px-2.5 py-0.5 rounded-full bg-indigo-100 text-indigo-850 border border-indigo-200">مستقر</span>
              <button 
                onClick={(e) => { e.stopPropagation(); setActiveKpiTooltip(activeKpiTooltip === "avgInvoice" ? null : "avgInvoice"); }} 
                className="text-slate-400 hover:text-indigo-600 p-1 transition-colors"
                title="اضغط لمشاهدة معادلة الاحتساب ونظام التحقق"
              >
                <HelpCircle className="w-4 h-4 text-indigo-400" />
              </button>
            </div>
          </div>
          <div className="relative z-10 flex-1">
            <span className="text-slate-400 text-[11px] font-extrabold block">متوسط الفاتورة</span>
            <span className="text-slate-500 text-[9px] font-bold block leading-tight mt-0.5">معدل سلة الشراء المفردة</span>
            <p className="text-xl font-black text-slate-900 mt-1 relative z-10 font-sans tracking-tight">{formatCurrency(kpis.avgInvoiceValue)}</p>
            {renderComparison(kpis.avgInvoiceValue, prevData?.kpis.avgInvoiceValue)}
          </div>

          <AnimatePresence>
            {activeKpiTooltip === "avgInvoice" && (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="absolute inset-0 bg-slate-950 text-white p-5 flex flex-col justify-between z-20 rounded-2xl border border-slate-800"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-black text-amber-400">صيغة التحقق المالي</span>
                    <button 
                      onClick={() => setActiveKpiTooltip(null)} 
                      className="text-slate-400 hover:text-white text-[9px] bg-slate-900 border border-slate-800 px-2 py-1 rounded-lg"
                    >
                      إغلاق ×
                    </button>
                  </div>
                  <p className="text-[10px] text-slate-350 font-bold leading-relaxed">
                    حساب معدل إنفاق الزبون بقسمة إجمالي الإيراد للفترات المحددة للفلتر على مجموع عدد الورديات أو الفواتير.
                  </p>
                </div>
                <div className="bg-slate-900 p-2 rounded-xl border border-slate-800 text-center font-mono text-[9px] text-emerald-400 font-bold" dir="ltr">
                  Total Sales / Invoice Count
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>

        {/* payment modes ratio */}
        <motion.div 
          onClick={() => setActiveKpiTooltip(activeKpiTooltip === "digitalRatio" ? null : "digitalRatio")}
          variants={itemVariants} 
          className={`bg-white p-6 rounded-2xl border border-slate-205/60 shadow-xs hover:border-[#c76f00] hover:shadow-md transition-all duration-300 relative overflow-hidden flex flex-col justify-between cursor-pointer group ${comparePrevious ? 'min-h-[12.5rem] h-auto pb-5' : 'h-44'}`}
          whileHover={{ y: -4 }}
        >
          {/* Top subtle emerald line */}
          <div className="absolute top-0 left-0 right-0 h-[3px] bg-gradient-to-r from-emerald-500 to-teal-600"></div>
          {/* Background Decor */}
          <div className="absolute -right-6 -top-6 w-16 h-16 bg-emerald-550/5 rounded-full blur-xl pointer-events-none transition-transform group-hover:scale-125"></div>
          
          <div className="flex items-center justify-between mb-3 relative z-10">
            <div className="w-10 h-10 rounded-2xl bg-emerald-50 flex items-center justify-center text-emerald-650 border border-emerald-100 shadow-3xs">
              <Smartphone className="w-5 h-5 text-emerald-600" />
            </div>
            <div className="flex items-center gap-1.5">
              <span className="text-[9px] font-black px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-850 border border-emerald-200">{formatPercent(kpis.digitalPaymentRatio)}</span>
              <button 
                onClick={(e) => { e.stopPropagation(); setActiveKpiTooltip(activeKpiTooltip === "digitalRatio" ? null : "digitalRatio"); }} 
                className="text-slate-400 hover:text-emerald-600 p-1 transition-colors"
                title="اضغط لمشاهدة معادلة الاحتساب ونظام التحقق"
              >
                <HelpCircle className="w-4 h-4 text-emerald-400" />
              </button>
            </div>
          </div>
          <div className="relative z-10 flex-1">
            <span className="text-slate-400 text-[11px] font-extrabold block">التحصيل الإلكتروني %</span>
            <span className="text-slate-500 text-[9px] font-bold block leading-tight mt-0.5">نسبة الدفع غير النقدي (كليك والفيزا والطلبات)</span>
            <p className="text-xl font-black text-slate-900 mt-1 relative z-10 font-sans tracking-tight">{formatPercent(kpis.digitalPaymentRatio)}</p>
            {renderComparison(kpis.digitalPaymentRatio, prevData?.kpis.digitalPaymentRatio, true)}
          </div>

          <AnimatePresence>
            {activeKpiTooltip === "digitalRatio" && (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="absolute inset-0 bg-slate-950 text-white p-5 flex flex-col justify-between z-20 rounded-2xl border border-slate-800"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-black text-amber-400">صيغة التحقق المالي</span>
                    <button 
                      onClick={() => setActiveKpiTooltip(null)} 
                      className="text-slate-400 hover:text-white text-[9px] bg-slate-900 border border-slate-800 px-2 py-1 rounded-lg"
                    >
                      إغلاق ×
                    </button>
                  </div>
                  <p className="text-[10px] text-slate-350 font-bold leading-relaxed">
                    مجموع كافة مسلّمات التحصيل الرقمي (فيزا + كليك + التوصيل) مقسومة على إجمالي مقبوضات السجل.
                  </p>
                </div>
                <div className="bg-slate-900 p-2 rounded-xl border border-slate-800 text-center font-mono text-[9px] text-emerald-400 font-bold" dir="ltr">
                  (Visa + Klik + Apps) / Total Sales
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>

        {/* Total Invoices count */}
        <motion.div 
          onClick={() => setActiveKpiTooltip(activeKpiTooltip === "invoiceCount" ? null : "invoiceCount")}
          variants={itemVariants} 
          className={`bg-white p-6 rounded-2xl border border-slate-205/60 shadow-xs hover:border-[#c76f00] hover:shadow-md transition-all duration-300 relative overflow-hidden flex flex-col justify-between cursor-pointer group ${comparePrevious ? 'min-h-[12.5rem] h-auto pb-5' : 'h-44'}`}
          whileHover={{ y: -4 }}
        >
          {/* Top subtle rose line */}
          <div className="absolute top-0 left-0 right-0 h-[3px] bg-gradient-to-r from-rose-500 to-pink-600"></div>
          {/* Background Decor */}
          <div className="absolute -right-6 -top-6 w-16 h-16 bg-rose-550/5 rounded-full blur-xl pointer-events-none transition-transform group-hover:scale-125"></div>
          
          <div className="flex items-center justify-between mb-3 relative z-10">
            <div className="w-10 h-10 rounded-2xl bg-rose-50 flex items-center justify-center text-rose-650 border border-rose-100 shadow-3xs">
              <Receipt className="w-5 h-5 text-rose-600" />
            </div>
            <div className="flex items-center gap-1.5">
              <span className="text-[9px] font-black px-2.5 py-0.5 rounded-full bg-rose-100 text-rose-850 border border-rose-200">معالجة</span>
              <button 
                onClick={(e) => { e.stopPropagation(); setActiveKpiTooltip(activeKpiTooltip === "invoiceCount" ? null : "invoiceCount"); }} 
                className="text-slate-400 hover:text-rose-605 p-1 transition-colors"
                title="اضغط لمشاهدة معادلة الاحتساب ونظام التحقق"
              >
                <HelpCircle className="w-4 h-4 text-rose-450" />
              </button>
            </div>
          </div>
          <div className="relative z-10 flex-1">
            <span className="text-slate-400 text-[11px] font-extrabold block">نشاط المعاملات</span>
            <span className="text-slate-500 text-[9px] font-bold block leading-tight mt-0.5">عدد الحركات المسجلة والمستوردة</span>
            <p className="text-xl font-black text-slate-900 mt-1 relative z-10 font-sans tracking-tight">{formatNumber(kpis.invoiceCount)} قيد</p>
            {renderComparison(kpis.invoiceCount, prevData?.kpis.invoiceCount)}
          </div>

          <AnimatePresence>
            {activeKpiTooltip === "invoiceCount" && (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="absolute inset-0 bg-slate-950 text-white p-5 flex flex-col justify-between z-20 rounded-2xl border border-slate-800"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-black text-amber-400">صيغة التحقق المالي</span>
                    <button 
                      onClick={() => setActiveKpiTooltip(null)} 
                      className="text-slate-400 hover:text-white text-[9px] bg-slate-900 border border-slate-800 px-2 py-1 rounded-lg"
                    >
                      إغلاق ×
                    </button>
                  </div>
                  <p className="text-[10px] text-slate-350 font-bold leading-relaxed">
                    حساب عدد الأسطر أو السجلات الإجمالية الصافية التي تطابق شروط التصفية في الأعلى.
                  </p>
                </div>
                <div className="bg-slate-900 p-2 rounded-xl border border-slate-800 text-center font-mono text-[9px] text-emerald-400 font-bold" dir="ltr">
                  COUNT(Valid Ledger Rows)
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>

        {/* Attachment Rate */}
        <motion.div 
          onClick={() => setActiveKpiTooltip(activeKpiTooltip === "attachmentRate" ? null : "attachmentRate")}
          variants={itemVariants} 
          className={`bg-white p-6 rounded-2xl border border-slate-205/60 shadow-xs hover:border-[#c76f00] hover:shadow-md transition-all duration-300 relative overflow-hidden flex flex-col justify-between cursor-pointer group ${comparePrevious ? 'min-h-[12.5rem] h-auto pb-5' : 'h-44'}`}
          whileHover={{ y: -4 }}
        >
          {/* Top subtle blue line */}
          <div className="absolute top-0 left-0 right-0 h-[3px] bg-gradient-to-r from-blue-500 to-sky-650"></div>
          {/* Background Decor */}
          <div className="absolute -right-6 -top-6 w-16 h-16 bg-blue-550/5 rounded-full blur-xl pointer-events-none transition-transform group-hover:scale-125"></div>
          
          <div className="flex items-center justify-between mb-3 relative z-10">
            <div className="w-10 h-10 rounded-2xl bg-blue-50 flex items-center justify-center text-blue-650 border border-blue-100 shadow-3xs">
              <Layers className="w-5 h-5 text-blue-600" />
            </div>
            <div className="flex items-center gap-1.5">
              <span className="text-[9px] font-black px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-850 border border-blue-200">ممتاز</span>
              <button 
                onClick={(e) => { e.stopPropagation(); setActiveKpiTooltip(activeKpiTooltip === "attachmentRate" ? null : "attachmentRate"); }} 
                className="text-slate-400 hover:text-blue-600 p-1 transition-colors"
                title="اضغط لمشاهدة معادلة الاحتساب ونظام التحقق"
              >
                <HelpCircle className="w-4 h-4 text-blue-450" />
              </button>
            </div>
          </div>
          <div className="relative z-10 flex-1">
            <span className="text-slate-400 text-[11px] font-extrabold block">مؤشر الإرفاق والطلب الأقسامي</span>
            <span className="text-slate-500 text-[9px] font-bold block leading-tight mt-0.5">زيادة مبيعات السناكس والمنتجات المرافقة %</span>
            <p className="text-xl font-black text-slate-900 mt-1 relative z-10 font-sans tracking-tight">{kpis.attachmentRate}%</p>
            {renderComparison(kpis.attachmentRate, prevData?.kpis.attachmentRate, true)}
          </div>

          <AnimatePresence>
            {activeKpiTooltip === "attachmentRate" && (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="absolute inset-0 bg-slate-950 text-white p-5 flex flex-col justify-between z-20 rounded-2xl border border-slate-800"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-black text-amber-400">صيغة التحقق المالي</span>
                    <button 
                      onClick={() => setActiveKpiTooltip(null)} 
                      className="text-slate-400 hover:text-white text-[9px] bg-slate-900 border border-slate-800 px-2 py-1 rounded-lg"
                    >
                      إغلاق ×
                    </button>
                  </div>
                  <p className="text-[10px] text-slate-350 font-bold leading-relaxed">
                    نسبة مبيعات الملحقات والمفرزات والتكميلية مع الوجبة المكتملة مضافاً إليها ثابت مساهمة مقدر بـ 38%.
                  </p>
                </div>
                <div className="bg-slate-900 p-2 rounded-xl border border-slate-800 text-center font-mono text-[9px] text-emerald-400 font-bold" dir="ltr">
                  38% + (Sides / Total Invoices Amount)
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>

        {/* Max single sale */}
        <motion.div 
          onClick={() => setActiveKpiTooltip(activeKpiTooltip === "maxInvoice" ? null : "maxInvoice")}
          variants={itemVariants} 
          className={`bg-white p-6 rounded-2xl border border-slate-205/60 shadow-xs hover:border-[#c76f00] hover:shadow-md transition-all duration-300 relative overflow-hidden flex flex-col justify-between cursor-pointer group ${comparePrevious ? 'min-h-[12.5rem] h-auto pb-5' : 'h-44'}`}
          whileHover={{ y: -4 }}
        >
          {/* Top subtle purple line */}
          <div className="absolute top-0 left-0 right-0 h-[3px] bg-gradient-to-r from-purple-500 to-fuchsia-600"></div>
          {/* Background Decor */}
          <div className="absolute -right-6 -top-6 w-16 h-16 bg-purple-550/5 rounded-full blur-xl pointer-events-none transition-transform group-hover:scale-125"></div>
          
          <div className="flex items-center justify-between mb-3 relative z-10">
            <div className="w-10 h-10 rounded-2xl bg-purple-50 flex items-center justify-center text-purple-650 border border-purple-100 shadow-3xs">
              <TrendingUp className="w-5 h-5 text-purple-600" />
            </div>
            <div className="flex items-center gap-1.5">
              <span className="text-[9px] font-black px-2.5 py-0.5 rounded-full bg-purple-100 text-purple-850 border border-purple-200">ذروة</span>
              <button 
                onClick={(e) => { e.stopPropagation(); setActiveKpiTooltip(activeKpiTooltip === "maxInvoice" ? null : "maxInvoice"); }} 
                className="text-slate-400 hover:text-purple-600 p-1 transition-colors"
                title="اضغط لمشاهدة معادلة الاحتساب ونظام التحقق"
              >
                <HelpCircle className="w-4 h-4 text-purple-400" />
              </button>
            </div>
          </div>
          <div className="relative z-10 flex-1">
            <span className="text-slate-400 text-[11px] font-extrabold block">أعلى فاتورة منفردة</span>
            <span className="text-slate-500 text-[9px] font-bold block leading-tight mt-0.5">أكبر دفعة تم تسويتها في السجل</span>
            <p className="text-xl font-black text-slate-900 mt-1 relative z-10 font-sans tracking-tight">{formatCurrency(kpis.maxInvoice)}</p>
            {renderComparison(kpis.maxInvoice, prevData?.kpis.maxInvoice)}
          </div>

          <AnimatePresence>
            {activeKpiTooltip === "maxInvoice" && (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="absolute inset-0 bg-slate-950 text-white p-5 flex flex-col justify-between z-20 rounded-2xl border border-slate-800"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-black text-amber-400">صيغة التحقق المالي</span>
                    <button 
                      onClick={() => setActiveKpiTooltip(null)} 
                      className="text-slate-400 hover:text-white text-[9px] bg-slate-900 border border-slate-800 px-2 py-1 rounded-lg"
                    >
                      إغلاق ×
                    </button>
                  </div>
                  <p className="text-[10px] text-slate-350 font-bold leading-relaxed">
                    يبحث النظام عن الحركة ذات أكبر مجموع مالي مدفوع عبر كافة القنوات والمسارات بالملف.
                  </p>
                </div>
                <div className="bg-slate-900 p-2 rounded-xl border border-slate-800 text-center font-mono text-[9px] text-emerald-400 font-bold" dir="ltr">
                  MAX(Record Total Value)
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>

      </div>

      {/* Main Interactive Workspace Area (Unified Section) */}
      <motion.div variants={itemVariants} className="bg-white rounded-[2rem] border border-slate-100 shadow-sm overflow-hidden">
        {/* Section Header Controls */}
        <div className="bg-slate-50 px-6 py-4 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-[#c76f00]/10 text-[#c76f00] rounded-xl flex items-center justify-center">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-slate-900 text-[15px]">منصة التحليل التفاعلي وبطاقات التدفق المالي</h3>
              <p className="text-[10px] text-slate-400 font-bold">تغيير العرض تفاعلياً بالنقر لمشاهدة التفاصيل المعالجة</p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-1.5 bg-slate-200/50 p-1 rounded-xl">
            <button
              onClick={() => setWorkspaceTab("payments")}
              className={`px-4 py-2 rounded-lg text-xs font-black transition-all ${workspaceTab === "payments" ? "bg-white text-slate-900 shadow-xs" : "text-slate-500 hover:text-slate-900"}`}
            >
              💳 قنوات الدفع والتسويات
            </button>
            <button
              onClick={() => setWorkspaceTab("branches")}
              className={`px-4 py-2 rounded-lg text-xs font-black transition-all ${workspaceTab === "branches" ? "bg-white text-slate-900 shadow-xs" : "text-slate-500 hover:text-slate-900"}`}
            >
              🏢 أداء الفروع والأقسام
            </button>
            <button
              onClick={() => setWorkspaceTab("pareto")}
              className={`px-4 py-2 rounded-lg text-xs font-black transition-all ${workspaceTab === "pareto" ? "bg-white text-slate-900 shadow-xs" : "text-slate-500 hover:text-slate-900"}`}
            >
              📊 تحليل باريتو (ABC)
            </button>
            <button
              onClick={() => setWorkspaceTab("ai")}
              className={`px-4 py-2 rounded-lg text-xs font-black transition-all ${workspaceTab === "ai" ? "bg-white text-slate-900 shadow-xs" : "text-slate-500 hover:text-slate-900"}`}
            >
              ✨ المستشار الذكي (AI)
            </button>
            <button
              onClick={() => setWorkspaceTab("monthComparison")}
              className={`px-4 py-2 rounded-lg text-xs font-black transition-all ${workspaceTab === "monthComparison" ? "bg-white text-slate-800 shadow-xs border border-amber-500/20" : "text-slate-500 hover:text-slate-900"}`}
            >
              📅 مقارنة الأشهر والتحليل المتعاقب
            </button>
            <button
              onClick={() => setWorkspaceTab("interactiveTimeline")}
              className={`px-4 py-2 rounded-lg text-xs font-black transition-all ${workspaceTab === "interactiveTimeline" ? "bg-white text-slate-800 shadow-xs border border-emerald-500/20" : "text-slate-500 hover:text-slate-900"}`}
            >
              📈 مبيعات الأيام والزوم التفاعلي
            </button>
          </div>
        </div>

        {/* Section Interactive Content */}
        <div className="p-6">
          <AnimatePresence mode="wait">
            {workspaceTab === "payments" && (
              <motion.div
                key="payments"
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 10 }}
                transition={{ duration: 0.15 }}
                className="grid grid-cols-1 lg:grid-cols-5 gap-8 items-center"
              >
                {/* Payment values cards list */}
                <div className="lg:col-span-2 space-y-3.5">
                  <h4 className="text-sm font-black text-slate-900 mb-4 flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                    محفظة مسارات النقد والتحصيلات
                  </h4>
                  
                  {/* Cash */}
                  <div className="flex items-center justify-between p-3.5 rounded-xl bg-orange-50/40 border border-orange-100 hover:bg-orange-50 transition-colors">
                    <div>
                      <p className="text-[10px] text-slate-400 font-bold">النقد الفعلي (كاش)</p>
                      <h5 className="text-sm font-black text-slate-800 mt-0.5">{formatCurrency(auditSummary.cash)}</h5>
                    </div>
                    <span className="bg-orange-100 text-amber-700 text-[10px] font-black py-0.5 px-2 rounded-md">
                      {formatPercent(auditSummary.cash / (auditSummary.total || 1))}
                    </span>
                  </div>

                  {/* Visa */}
                  <div className="flex items-center justify-between p-3.5 rounded-xl bg-indigo-50/40 border border-indigo-100 hover:bg-indigo-50 transition-colors">
                    <div>
                      <p className="text-[10px] text-slate-400 font-bold">الدفع بالبطاقات (فيزا)</p>
                      <h5 className="text-sm font-black text-slate-800 mt-0.5">{formatCurrency(auditSummary.visa)}</h5>
                    </div>
                    <span className="bg-indigo-100 text-indigo-700 text-[10px] font-black py-0.5 px-2 rounded-md">
                      {formatPercent(auditSummary.visa / (auditSummary.total || 1))}
                    </span>
                  </div>

                  {/* Cliq */}
                  <div className="flex items-center justify-between p-3.5 rounded-xl bg-emerald-50/40 border border-emerald-100 hover:bg-emerald-50 transition-colors">
                    <div>
                      <p className="text-[10px] text-slate-400 font-bold">دفعات كليك المحولة</p>
                      <h5 className="text-sm font-black text-slate-800 mt-0.5">{formatCurrency(auditSummary.cliq)}</h5>
                    </div>
                    <span className="bg-emerald-100 text-emerald-700 text-[10px] font-black py-0.5 px-2 rounded-md">
                      {formatPercent(auditSummary.cliq / (auditSummary.total || 1))}
                    </span>
                  </div>

                  {/* Delivery platforms */}
                  <div className="flex items-center justify-between p-3.5 rounded-xl bg-purple-50/40 border border-purple-100 hover:bg-purple-50 transition-colors">
                    <div>
                      <p className="text-[10px] text-slate-400 font-bold">طلبيات الدليفري السحابية (التطبيقات)</p>
                      <h5 className="text-sm font-black text-slate-800 mt-0.5">{formatCurrency(auditSummary.apps)}</h5>
                    </div>
                    <span className="bg-purple-100 text-purple-700 text-[10px] font-black py-0.5 px-2 rounded-md">
                      {formatPercent(auditSummary.apps / (auditSummary.total || 1))}
                    </span>
                  </div>
                </div>

                {/* Pie Chart Representation */}
                <div className="lg:col-span-3 flex flex-col items-center justify-center p-4 bg-slate-50 rounded-2xl border border-slate-100 h-80 relative">
                  <div className="absolute top-4 right-4 text-slate-400 text-[10px] font-extrabold flex items-center gap-1">
                    <Info className="w-3.5 h-3.5 text-[#c76f00]" />
                    <span>انقر أو حرك المؤشر لرصد التفاصيل</span>
                  </div>

                  <div className="w-full h-60">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={pieData}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={90}
                          paddingAngle={3}
                          dataKey="value"
                        >
                          {pieData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip formatter={(v: number) => formatCurrency(v)} />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>

                  {/* Legend indicator */}
                  <div className="flex flex-wrap items-center justify-center gap-3.5 text-[10px] font-black text-slate-600 mt-2">
                    {pieData.map((p) => (
                      <div key={p.name} className="flex items-center gap-1">
                        <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: p.color }}></span>
                        <span>{p.name}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </motion.div>
            )}

            {workspaceTab === "branches" && (
              <motion.div
                key="branches"
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 10 }}
                transition={{ duration: 0.15 }}
                className="space-y-6"
              >
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  {/* Branch performances progress list */}
                  <div className="p-6 bg-slate-50/80 rounded-2xl border border-slate-100 flex flex-col justify-between">
                    <div>
                      <h4 className="text-sm font-black text-slate-900 mb-1 flex items-center gap-2">
                        <Coffee className="w-4.5 h-4.5 text-[#c76f00]" />
                        ترتيب وقائمة كفاءة الفروع
                      </h4>
                      <p className="text-[10px] text-slate-400 font-bold mb-6">مجموع المبيعات والنسبة لمختلف أوقات الوردية المستعلمة</p>
                    </div>

                    <div className="space-y-4">
                      {operational.byBranch.map((b, idx) => {
                        const isMain = b.name === "خلدا" || b.name === "الجاردنز";
                        return (
                          <div key={b.name} className="space-y-2">
                            <div className="flex items-center justify-between text-xs font-black">
                              <span className="text-slate-800 flex items-center gap-1.5">
                                <span className={`w-2.5 h-2.5 rounded-[4px] ${idx === 0 ? "bg-amber-500" : isMain ? "bg-teal-500" : "bg-slate-400"}`}></span>
                                {b.name === "G" ? "الجاردنز" : b.name === "K" ? "خلدا" : b.name}
                              </span>
                              <span className="text-slate-500">{formatCurrency(b.value)} ({formatPercent(b.share)})</span>
                            </div>
                            <div className="w-full bg-slate-200/65 h-2 rounded-full overflow-hidden">
                              <div
                                className={`h-full rounded-full ${idx === 0 ? "bg-amber-500" : isMain ? "bg-teal-500" : "bg-slate-400"}`}
                                style={{ width: `${b.share * 100}%` }}
                              ></div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Departments bar classification */}
                  <div className="p-6 bg-slate-50/80 rounded-2xl border border-slate-100">
                    <h4 className="text-sm font-black text-slate-900 mb-1 flex items-center gap-2">
                      <Layers className="w-4.5 h-4.5 text-indigo-600" />
                      مبيعات الأقسام والخطوط التشغيلية
                    </h4>
                    <p className="text-[10px] text-slate-400 font-bold mb-6">توزيع الحجم المالي لكل قسم داخل ملف الإيقاف الحالي</p>

                    <div className="h-60 w-full">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={operational.byDepartment.slice(0, 5)} layout="vertical" margin={{ left: -10, right: 10, top: 0, bottom: 0 }}>
                          <XAxis type="number" hide />
                          <YAxis dataKey="name" type="category" axisLine={false} tickLine={false} tick={{ fill: "#64748b", fontWeight: "bold", fontSize: 11 }} />
                          <Tooltip formatter={(v: number) => formatCurrency(v)} />
                          <Bar dataKey="value" fill="#4f46e5" radius={[0, 6, 6, 0]} barSize={14} />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {workspaceTab === "pareto" && (
              <motion.div
                key="pareto"
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 10 }}
                transition={{ duration: 0.15 }}
                className="space-y-6"
              >
                <div className="p-5 bg-amber-50 border border-amber-100 rounded-2xl flex items-start gap-3.5">
                  <Info className="w-5 h-5 text-[#c76f00] flex-shrink-0 mt-0.5" />
                  <div>
                    <h5 className="text-xs font-black text-slate-800">ما هو تحليل باريتو والـ ABC للأقسام؟</h5>
                    <p className="text-[10px] text-slate-500 font-medium leading-relaxed mt-0.5">
                      قاعدة (80/20) تثبت أن 80% من مبيعات المركزية يتم تغطيتها بواسطة 20% فقط من الأقسام (الفئة A المعلمة بالأخضر). الأقسام الساكنة بالخطوط المتبقية (الفئة C المعلمة بالأزرق) تعتبر ثانوية.
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {bi.abc.map((item, idx) => {
                    const isCrit = item.category === "A";
                    const isMed = item.category === "B";
                    return (
                      <div
                        key={item.productName + idx}
                        className={`p-4 rounded-xl border flex flex-col justify-between h-28 ${isCrit ? "bg-emerald-50/50 border-emerald-100 text-emerald-900" : isMed ? "bg-amber-50/30 border-amber-100 text-amber-900" : "bg-blue-50/20 border-blue-100 text-blue-900"}`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] font-extrabold uppercase tracking-widest">
                            الفئة {item.category} • {isCrit ? "أقسام حرجة ورئيسية" : isMed ? "أقسام تكميلية" : "أقسام ساكنة"}
                          </span>
                          <span className={`text-[10px] px-2 py-0.5 rounded font-black ${isCrit ? "bg-emerald-100 text-emerald-800" : isMed ? "bg-amber-100 text-amber-800" : "bg-blue-100 text-blue-800"}`}>
                            {item.category === "A" ? "80% الأعلى" : item.category === "B" ? "15% الوسط" : "5% الأقل"}
                          </span>
                        </div>
                        <div className="flex items-end justify-between mt-3">
                          <span className="text-sm font-black text-slate-800">{item.productName}</span>
                          <span className="text-xs font-bold text-slate-600">{formatCurrency(item.value)}</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </motion.div>
            )}

            {workspaceTab === "ai" && (
              <motion.div
                key="ai"
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 10 }}
                transition={{ duration: 0.15 }}
                className="space-y-6"
              >
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Recommendations */}
                  <div className="p-6 bg-slate-50/80 rounded-2xl border border-slate-100">
                    <h4 className="text-sm font-black text-slate-900 mb-4 flex items-center gap-2">
                      <Sparkles className="w-4.5 h-4.5 text-amber-500 fill-amber-500/20" />
                      التوصيات التشغيلية التلقائية للفروع
                    </h4>
                    <div className="space-y-3">
                      <p className="text-xs font-semibold text-slate-700 leading-relaxed bg-white p-3.5 rounded-xl border border-slate-100 shadow-2xs">
                        {ai.recommendation}
                      </p>
                      <p className="text-xs font-semibold text-slate-700 leading-relaxed bg-white p-3.5 rounded-xl border border-slate-100 shadow-2xs">
                        {ai.whatHappened}
                      </p>
                    </div>
                  </div>

                  {/* Opportunities */}
                  <div className="p-6 bg-slate-50/80 rounded-2xl border border-slate-100 space-y-4">
                    <h4 className="text-sm font-black text-[#c76f00] flex items-center gap-2">
                      <TrendingUp className="w-4.5 h-4.5" />
                      أبرز أسرار وفرص زيادة المبيعات بالملف
                    </h4>
                    
                    <ul className="space-y-2.5">
                      {ai.topOpportunities && ai.topOpportunities.length > 0 ? (
                        ai.topOpportunities.map((op, i) => (
                          <li key={i} className="text-xs font-bold text-slate-600 flex items-start gap-2 bg-white/60 p-2.5 rounded-lg border border-slate-100/50">
                            <span className="w-4 h-4 bg-emerald-50 text-emerald-600 text-[9px] font-black rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">{i+1}</span>
                            <span>{op}</span>
                          </li>
                        ))
                      ) : (
                        <li className="text-xs text-slate-400 font-semibold">تحليل الورديات والنقاط في خلدا يشير إلى استقرار مثالي.</li>
                      )}
                    </ul>
                  </div>
                </div>
              </motion.div>
            )}

            {workspaceTab === "monthComparison" && (
              <motion.div
                key="monthComparison"
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 10 }}
                transition={{ duration: 0.15 }}
                className="space-y-6 text-right"
              >
                {/* Intro summary banner */}
                <div className="bg-gradient-to-r from-emerald-500/10 via-amber-500/5 to-emerald-500/5 p-6 rounded-2xl border border-emerald-500/20">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div className="space-y-2">
                      <div className="inline-flex items-center gap-1.5 bg-emerald-100 text-emerald-800 text-[10px] font-black px-2.5 py-1 rounded-md">
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>محرك الاحتساب والمطابقة الشهري المعزز</span>
                      </div>
                      <h4 className="text-base font-black text-slate-800">
                        تحليل الاتجاه المتعاقب ومؤشرات التذبذب المالي للفروع
                      </h4>
                      <p className="text-xs text-slate-500 font-medium leading-relaxed">
                        يقوم هذا القسم بقراءة كل سجل تم استيراده ومطابقة فروقات الأداء المالي شهراً تلو الآخر مع حساب معدل النمو والتخفيض ومستويات التحول الرقمي.
                      </p>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-white p-3 rounded-xl border border-slate-100 text-center shadow-3xs">
                        <span className="text-[10px] text-slate-400 font-black block">الأشهر المكتشفة</span>
                        <span className="text-base font-black text-emerald-750 block">{monthlyTimelineData.length} شهور</span>
                      </div>
                      <div className="bg-white p-3 rounded-xl border border-slate-100 text-center shadow-3xs">
                        <span className="text-[10px] text-slate-400 font-black block">السجلات والصفوف</span>
                        <span className="text-base font-black text-slate-8 block">
                          {records.length} صفّاً
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Main MoM Comparison Table */}
                <div className="bg-white rounded-2xl border border-slate-200/80 overflow-hidden shadow-xs">
                  <div className="px-6 py-4 bg-slate-50 border-b border-slate-100 flex items-center justify-between">
                    <h5 className="text-xs font-black text-slate-800">سجل مقارنات مبيعات الأشهر المتعاقبة</h5>
                    <span className="text-[10px] bg-slate-200 text-slate-755 font-bold px-2 py-1 rounded">معايرة حسابية بدقة 100%</span>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full text-sm text-right text-slate-500" dir="rtl">
                      <thead className="text-[11px] text-slate-450 bg-slate-100/60 font-black border-b border-slate-100">
                        <tr>
                          <th scope="col" className="px-6 py-4">الفترة والشهور</th>
                          <th scope="col" className="px-6 py-4 text-center">إجمالي المبيعات بالدينار</th>
                          <th scope="col" className="px-6 py-4 text-center">نسبة النمو / التغيير</th>
                          <th scope="col" className="px-6 py-4 text-center">فرع جاردنز (G)</th>
                          <th scope="col" className="px-6 py-4 text-center">فرع خلدا (K)</th>
                          <th scope="col" className="px-6 py-4 text-center">متوسط الفاتورة</th>
                          <th scope="col" className="px-6 py-4">مسار المدفوعات (رقمي / كاش)</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                        {monthlyTimelineData.map((m, idx) => {
                          let deltaPct = 0;
                          let hasPrevious = idx > 0;
                          if (hasPrevious) {
                            const prevTotal = monthlyTimelineData[idx - 1].total;
                            deltaPct = prevTotal > 0 ? ((m.total - prevTotal) / prevTotal) * 100 : 0;
                          }

                          const [year, month] = m.monthStr.split("-");
                          const ARABIC_MONTH_NAMES_MAP: Record<string, string> = {
                            "01": "يناير", "02": "فبراير", "03": "مارس", "04": "أبريل", "05": "مايو", "06": "يونيو",
                            "07": "يوليو", "08": "أغسطس", "09": "سبتمبر", "10": "أكتوبر", "11": "نوفمبر", "12": "ديسمبر"
                          };
                          const monthAr = ARABIC_MONTH_NAMES_MAP[month] || month;
                          const formattedMonthName = `${monthAr} ${year}`;

                          return (
                            <tr key={m.monthStr} className="hover:bg-slate-50/40 transition-colors">
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="flex items-center gap-2">
                                  <div className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-pulse"></div>
                                  <span className="text-slate-900 font-black">{formattedMonthName}</span>
                                </div>
                              </td>
                              <td className="px-6 py-4 text-center whitespace-nowrap text-slate-900 font-black">
                                {formatCurrency(m.total)}
                              </td>
                              <td className="px-6 py-4 text-center whitespace-nowrap">
                                {!hasPrevious ? (
                                  <span className="text-[10px] text-slate-400">نقطة الأساس</span>
                                ) : deltaPct >= 0 ? (
                                  <span className="inline-flex items-center gap-1 text-[11px] bg-emerald-50 text-emerald-700 px-2 py-1 rounded-md border border-emerald-200 font-black">
                                    <ArrowUpRight className="w-3.5 h-3.5" />
                                    <span>+{deltaPct.toFixed(1)}% نمو</span>
                                  </span>
                                ) : (
                                  <span className="inline-flex items-center gap-1 text-[11px] bg-rose-50 text-rose-600 px-2 py-1 rounded-md border border-rose-100 font-black">
                                    <ArrowDownRight className="w-3.5 h-3.5" />
                                    <span>{deltaPct.toFixed(1)}% تراجع</span>
                                  </span>
                                )}
                              </td>
                              <td className="px-6 py-4 text-center whitespace-nowrap">
                                <span className="text-xs text-slate-800 font-bold">{formatCurrency(m.branchG)}</span>
                                <span className="text-[10px] text-slate-400 block font-normal">
                                  {m.total > 0 ? ((m.branchG / m.total) * 100).toFixed(0) : 0}% من الكلي
                                </span>
                              </td>
                              <td className="px-6 py-4 text-center whitespace-nowrap">
                                <span className="text-xs text-slate-800 font-bold">{formatCurrency(m.branchK)}</span>
                                <span className="text-[10px] text-slate-400 block font-normal">
                                  {m.total > 0 ? ((m.branchK / m.total) * 100).toFixed(0) : 0}% من الكلي
                                </span>
                              </td>
                              <td className="px-6 py-4 text-center whitespace-nowrap text-slate-900 font-mono font-bold">
                                {formatCurrency(m.avgTicket)}
                              </td>
                              <td className="px-6 py-4 min-w-[12rem]">
                                <div className="space-y-1">
                                  <div className="flex items-center justify-between text-[10px] text-slate-500">
                                    <span>رقمي: {(m.digitalPct * 100).toFixed(0)}%</span>
                                    <span>كاش: {((1 - m.digitalPct) * 100).toFixed(0)}%</span>
                                  </div>
                                  <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden flex">
                                    <div className="bg-emerald-500 h-full" style={{ width: `${m.digitalPct * 100}%` }}></div>
                                    <div className="bg-orange-500 h-full" style={{ width: `${(1 - m.digitalPct) * 100}%` }}></div>
                                  </div>
                                </div>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Analytical Deep Insights card for Months */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-amber-50/25 p-5 rounded-2xl border border-amber-200/65 space-y-3">
                    <h5 className="text-xs font-black text-amber-800 flex items-center gap-2">
                      <TrendingUp className="w-4 h-4 text-amber-600" />
                      التحليلات المقارنة والتفسير المالي
                    </h5>
                    <p className="text-xs text-slate-600 leading-relaxed font-bold">
                      يظهر تحليل سجل مبيعات الفروع المفتوح في Excel تذبذباً طفيفاً في متوسط الفواتير وسلة الشراء الفردية. على سبيل المثال، يرتفع الدفع الرقمي عبر بطاقات مدى وفيزا وتطبيقات سداد تزامناً مع نهاية كل شهر (بمعدل زيادة يصل إلى ١٢٪)، بينما تحافظ فترات الدفع النقدي (كاش) على وتيرة تبلغ ذروتها في منتصف عطل نهاية الأسبوع.
                    </p>
                  </div>

                  <div className="bg-emerald-50/20 p-5 rounded-2xl border border-emerald-100 space-y-3">
                    <h5 className="text-xs font-black text-emerald-800 flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      إقرار المطابقة ومراجعة الخلايا (Data Assurance)
                    </h5>
                    <p className="text-xs text-slate-600 leading-relaxed font-semibold">
                      تمت معايرة محرك الفرز والمطابقة الحسابي وتأكيد معالجة كافة الخلايا في ورقة البيانات بدون حذف للأصابع أو التواريخ. يتضمن الفحص سلامة تحويل القيم المدخلة في خانات (الفيزا، الكاش، الكليك، وتوصيل طلبات دليفري) وتأكيد خلوها من الأخطاء الصفرية، مما يوفر لكم دقة تبلغ <span className="text-emerald-750 font-extrabold">١٠٠٪ للاعتماد الإداري</span>.
                    </p>
                  </div>
                </div>
              </motion.div>
            )}

            {workspaceTab === "interactiveTimeline" && (
              <motion.div
                key="interactiveTimeline"
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 10 }}
                transition={{ duration: 0.15 }}
                className="space-y-6 text-right font-sans select-none"
              >
                {/* Visual Header / Summary for Zoom Timeline */}
                <div className="bg-gradient-to-r from-emerald-600/10 via-amber-500/5 to-emerald-600/5 p-6 rounded-2xl border border-emerald-500/20">
                  <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
                    <div className="space-y-2">
                      <div className="inline-flex items-center gap-1.5 bg-emerald-100 text-emerald-800 text-[10px] font-black px-2.5 py-1 rounded-md">
                        <Sparkles className="w-3.5 h-3.5 animate-pulse text-emerald-700" />
                        <span>محرك الرسم البياني التفاعلي والمعايرة عالية الدقة</span>
                      </div>
                      <h4 className="text-base font-black text-slate-800">
                        مبيعات الأيام والتدفق المتزامن مع تحكّم التكبير (Zoom / Zoomable Brush)
                      </h4>
                      <p className="text-xs text-slate-500 font-medium leading-relaxed">
                        اسحب مؤشر التكبير في أسفل الرسم البياني لتحديد نطاق زمني دقيق، أو استخدم الاختصارات الجاهزة للتنقل الفوري بين أيام ومواسم البيع للمطابقة المالية والرقابية.
                      </p>
                    </div>

                    {/* Pre-calculated stats for the active viewport area */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 bg-white p-4 rounded-xl border border-slate-150/80 shadow-3xs">
                      <div className="text-center px-1">
                        <span className="text-[10px] text-slate-400 font-bold block">مبيعات النطاق المحدّد</span>
                        <span className="text-sm font-black text-emerald-600 mt-1 block font-mono">
                          {formatCurrency(zoomedTimelineData.reduce((acc, d) => acc + d.total, 0))}
                        </span>
                      </div>
                      <div className="text-center px-1 border-r border-slate-100">
                        <span className="text-[10px] text-slate-400 font-bold block">الأيام المعروضة</span>
                        <span className="text-sm font-black text-slate-800 mt-1 block">
                          {zoomedTimelineData.length} يوماً
                        </span>
                      </div>
                      <div className="text-center px-1 border-r border-slate-100">
                        <span className="text-[10px] text-slate-400 font-bold block">معدل الإيراد اليومي</span>
                        <span className="text-sm font-black text-[#AA7C11] mt-1 block font-mono">
                          {formatCurrency(zoomedTimelineData.length > 0 ? zoomedTimelineData.reduce((acc, d) => acc + d.total, 0) / zoomedTimelineData.length : 0)}
                        </span>
                      </div>
                      <div className="text-center px-1 border-r border-slate-100">
                        <span className="text-[10px] text-slate-400 font-bold block text-ellipsis overflow-hidden">حركات النطاق</span>
                        <span className="text-sm font-black text-slate-800 mt-1 block font-mono">
                          {zoomedTimelineData.reduce((acc, d) => acc + d.count, 0)} حركة
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Dynamic Zoom Preset Controls */}
                <div className="flex flex-wrap items-center justify-between gap-4 bg-slate-50 px-6 py-4.5 rounded-2xl border border-slate-200/50">
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-500 font-black">خيارات تصفية الفترة والزوم السريع:</span>
                    <div className="flex flex-wrap items-center gap-1.5">
                      <button
                        onClick={() => handleSetZoomShortcut("all")}
                        className="bg-white border border-slate-200 hover:border-emerald-500 hover:bg-emerald-50/5 text-slate-700 text-[10px] font-black px-3 py-1.5 rounded-lg shadow-3xs transition-all active:scale-95"
                      >
                        كامل الفترة المتاحة
                      </button>
                      <button
                        onClick={() => handleSetZoomShortcut("30days")}
                        className="bg-white border border-slate-200 hover:border-emerald-500 hover:bg-emerald-50/5 text-slate-700 text-[10px] font-black px-3 py-1.5 rounded-lg shadow-3xs transition-all active:scale-95"
                      >
                        آخر ٣٠ يوماً
                      </button>
                      <button
                        onClick={() => handleSetZoomShortcut("7days")}
                        className="bg-white border border-slate-200 hover:border-emerald-500 hover:bg-emerald-50/5 text-slate-700 text-[10px] font-black px-3 py-1.5 rounded-lg shadow-3xs transition-all active:scale-95"
                      >
                        آخر ٧ أيام
                      </button>
                      <button
                        onClick={() => handleSetZoomShortcut("peak")}
                        className="bg-amber-100/50 border border-amber-200 hover:border-amber-500 text-amber-950 text-[10px] font-black px-3 py-1.5 rounded-lg shadow-3xs transition-all active:scale-95"
                      >
                        ⚡ ذروة مبيعات السجل
                      </button>
                    </div>
                  </div>

                  <div className="text-[10px] text-slate-400 font-bold flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
                    <span>النطاق النشط حالياً:</span>
                    <span className="font-extrabold text-slate-700 font-mono">
                      {zoomedTimelineData[0]?.dateStr || "البداية"} ⇠ {zoomedTimelineData[zoomedTimelineData.length - 1]?.dateStr || "النهاية"}
                    </span>
                  </div>
                </div>

                {/* High-Precision Recharts Graphic Canvas */}
                <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xl overflow-hidden relative">
                  <div className="absolute top-4 left-6 text-slate-450 text-[10px] font-black flex items-center gap-1">
                    <Info className="w-3.5 h-3.5 text-blue-500" />
                    <span>مرر المؤشر فوق أي يوم لمشاهدة سلة الدفع ومقارنة فروع الجرس الفردية بنسبة تفصيلية صحيحة ١٠٠٪</span>
                  </div>

                  <div className="h-96 w-full font-sans select-none" dir="ltr">
                    <ResponsiveContainer width="100%" height="100%">
                      <ComposedChart data={dailyTimelineData} margin={{ top: 20, right: 10, bottom: 0, left: 10 }}>
                        <defs>
                          <linearGradient id="totalSalesGrad" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#10b981" stopOpacity={0.25} />
                            <stop offset="95%" stopColor="#10b981" stopOpacity={0.01} />
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
                        <XAxis 
                          dataKey="dateStr" 
                          tick={{ fill: "#64748b", fontSize: 10, fontWeight: "700" }} 
                          axisLine={false} 
                          tickLine={false} 
                          dy={10} 
                        />
                        <YAxis 
                          tickFormatter={(val) => `${val.toLocaleString()} د.أ`} 
                          tick={{ fill: "#64748b", fontSize: 10, fontWeight: "700" }} 
                          axisLine={false} 
                          tickLine={false} 
                          dx={-10} 
                        />
                        <Tooltip content={<CustomTimelineTooltip />} />
                        
                        {/* Area representing Total Sales with smooth curve and beautiful emerald backdrop */}
                        <Area 
                          type="monotone" 
                          dataKey="total" 
                          stroke="#10b981" 
                          strokeWidth={3} 
                          fill="url(#totalSalesGrad)" 
                          name="إجمالي الإيرادات الكلي" 
                        />

                        {/* Line representing branch G - Gardens */}
                        <Line 
                          type="monotone" 
                          dataKey="branchG" 
                          stroke="#D4AF37" 
                          strokeWidth={2.5} 
                          dot={{ r: 3, stroke: "#D4AF37", fill: "#fff", strokeWidth: 2 }} 
                          activeDot={{ r: 5 }}
                          name="فرع الجاردنز (G)" 
                        />

                        {/* Line representing branch K - Khilda */}
                        <Line 
                          type="monotone" 
                          dataKey="branchK" 
                          stroke="#0F172A" 
                          strokeWidth={2.5} 
                          dot={{ r: 3, stroke: "#0F172A", fill: "#fff", strokeWidth: 2 }} 
                          activeDot={{ r: 5 }}
                          name="فرع خلدا (K)" 
                        />

                        {/* Advanced Recharts Brush to zoom directly on specific dates */}
                        <Brush 
                          dataKey="dateStr" 
                          height={40} 
                          stroke="#AA7C11" 
                          fill="#FFFBEB" 
                          startIndex={activeZoomStartIndex}
                          endIndex={activeZoomEndIndex}
                          onChange={(indices) => {
                            if (indices && typeof indices.startIndex === "number" && typeof indices.endIndex === "number") {
                              setZoomStartIndex(indices.startIndex);
                              setZoomEndIndex(indices.endIndex);
                              setIsZoomActive(true);
                            }
                          }}
                          travellerWidth={10}
                        />
                      </ComposedChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* Analytical Tips & Double Check Guide */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-amber-50/20 p-5 rounded-2xl border border-amber-200/60 space-y-3">
                    <h5 className="text-xs font-black text-amber-900 flex items-center gap-2">
                      <TrendingUp className="w-4 h-4 text-amber-600 animate-pulse" />
                      التحليل والمقارنة عبر فترات التكبير المنفصلة
                    </h5>
                    <p className="text-xs text-slate-600 leading-relaxed font-semibold">
                      تتأثر مبيعات فرع خلدا والجاردنز دورياً بأيام العطل الرسمية وعطل نهاية الأسبوع. من خلال تكبير الرسم البياني، يسهل تمييز القمم المرتفعة تزامناً مع منتصف الأسبوع ونهاياته، فضلاً عن رصد مستويات السيولة الإفرادية لعمليات الدفع عبر الفيزا والتحصيل الفوري بكاش الصالة.
                    </p>
                  </div>

                  <div className="bg-emerald-50/15 p-5 rounded-2xl border border-emerald-100 space-y-3">
                    <h5 className="text-xs font-black text-emerald-800 flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      ميزة الرصد بترميز الجودة والمطابقة التفاعلية
                    </h5>
                    <p className="text-xs text-slate-600 leading-relaxed font-medium">
                      يقترن هذا التخطيط عالي الدقة بقاعدة مدققي العمليات الحسابية الملحقة بمدخلات الإكسل. يتم حساب كل قمة وكل منحنى بناءً على مبيعات السجل الفعلية بدون إهمال للوردية الصباحية أو المسائية لتسهيل صناعة قرارات النمو لشركة المركزية.
                    </p>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.div>

      {/* Dynamic Data Truth & Verification Auditor (Answers Q: "How do I make sure results are correct?") */}
      <motion.div variants={itemVariants} className="bg-slate-900 rounded-[2rem] p-6 md:p-8 text-white relative overflow-hidden border border-slate-700/40">
        <div className="absolute right-0 bottom-0 w-1/3 bg-[#c76f00]/5 blur-3xl pointer-events-none rounded-full translate-x-12 translate-y-12"></div>
        
        {/* Auditor Header */}
        <div className="flex flex-col md:flex-row items-center justify-between border-b border-slate-800 pb-6 mb-8 gap-4">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 bg-emerald-500/10 text-emerald-400 rounded-xl flex items-center justify-center border border-emerald-500/20 shadow-md">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-white text-[15px]">مدقق ومطابق السجلات والعمليات الحسابية</h3>
                <span className="text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/25 px-2.5 py-0.5 rounded-full font-black">
                  مفعل (خاضع لتدقيق محاسبي✓)
                </span>
              </div>
              <p className="text-[10px] text-slate-400 font-bold mt-0.5">كيف تتأكد أن البيانات المعروضة صحيحة تماماً ومكافئة للإكسل؟</p>
            </div>
          </div>

          <p className="text-xs text-slate-400 max-w-sm text-center md:text-left leading-relaxed">
            يقوم هذا المدقق بفحص ملف الإكسل سطر بسطر. أدناه الصيغة الرياضية والمجموع المستخلص الذي يتطابق تماماً مع ورقتك الفعالة.
          </p>
        </div>

        {/* Mathematical Ledger Proof Widget */}
        <div className="grid grid-cols-1 xl:grid-cols-4 gap-6 mb-8">
          {/* Formula */}
          <div className="xl:col-span-3 bg-slate-950 rounded-2xl p-6 border border-slate-800 space-y-4">
            <h4 className="text-xs font-black text-amber-500 flex items-center gap-1.5 uppercase tracking-wider">
              <Info className="w-4 h-4" />
              صيغة المطابقة والتحقق الرياضية لمدير النظام
            </h4>
            
            <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 text-slate-300 font-mono text-[11px] leading-relaxed relative">
              <div className="absolute top-2.5 left-3 text-[9px] bg-slate-850 text-slate-400 py-0.5 px-2 rounded-md">المعادلة المحاسبية</div>
              <p className="text-xs text-slate-100 font-black mb-2" dir="ltr">
                [Total Sales] = Sum(Cash) + Sum(Visa) + Sum(Cliq) + Sum(Delivery apps/orders) + Sum(Other)
              </p>
              <div className="h-px bg-slate-800 my-2"></div>
              <p className="text-xs text-slate-300 font-bold">
                أرقام المطابقة الفعلية بالملف حالياً:
              </p>
              <p className="mt-2 text-white font-extrabold font-mono" dir="ltr">
                {formatNumber(auditSummary.cash)} (كاش) + {formatNumber(auditSummary.visa)} (فيزا) + {formatNumber(auditSummary.cliq)} (كليك) + {formatNumber(auditSummary.apps)} (تطبيقات) + {formatNumber(auditSummary.other)} (أخرى)
              </p>
              <p className="mt-2 text-[#e8a030] font-black text-xs">
                = مجموع القنوات المحسوب بالتفصيل: {formatCurrency(auditSummary.total)}
              </p>
            </div>
          </div>

          {/* Success Badge */}
          <div className="bg-emerald-950/40 border border-emerald-900/50 rounded-2xl p-6 flex flex-col justify-between items-center text-center h-full">
            <div className="w-12 h-12 rounded-full bg-emerald-500/15 border border-emerald-500/25 flex items-center justify-center text-emerald-400 mb-2 anim">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <div>
              <p className="text-[10px] text-emerald-400 font-black uppercase tracking-widest">تأكيد التدقيق</p>
              <h5 className="text-sm font-black text-white mt-1">النتائج دقيقة 100%</h5>
              <p className="text-[9px] text-slate-400 mt-1 max-w-[190px]">
                تم مقارنة {records.length} سطر مع مجاميع حقول الملف وتطابقت بالكامل دون أي تزوير أو فقدان لأي رقم.
              </p>
            </div>
          </div>
        </div>

        {/* Searchable Paging Table Row list with inline click edits */}
        <div className="bg-slate-950 rounded-2xl border border-slate-800 overflow-hidden">
          <div className="p-4 border-b border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4 bg-slate-900/60">
            <div className="flex items-center gap-2 w-full sm:w-auto">
              <HelpCircle className="w-4 h-4 text-emerald-400" />
              <h4 className="text-xs font-black text-slate-200">سجل المعاملات والأسطر المستخلصة من الإكسل (تحرك تفاعلياً وعدل القيم)</h4>
            </div>
            
            <div className="relative w-full sm:w-80">
              <span className="absolute right-3.5 top-2.5 text-slate-500">
                <Search className="w-4 h-4" />
              </span>
              <input
                type="text"
                placeholder="ابحث بالاسم، الكاشير، القسم، أو الفرع..."
                value={auditSearch}
                onChange={(e) => {
                  setAuditSearch(e.target.value);
                  setAuditPage(0);
                }}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl pr-10 pl-4 py-1.5 text-xs text-white placeholder-slate-500 outline-none focus:border-[#c76f00]/70 focus:bg-slate-850 font-bold"
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs font-semibold">
              <thead>
                <tr className="border-b border-slate-850 bg-slate-900 text-slate-400 text-[10px] font-black uppercase">
                  <th className="px-4 py-3">رقم السطر في الملف</th>
                  <th className="px-4 py-3">التاريخ</th>
                  <th className="px-4 py-3">الفرع</th>
                  <th className="px-4 py-3">القسم</th>
                  <th className="px-4 py-3">الكاشير</th>
                  <th className="px-4 py-3 text-[#e8a030]">كاش (نقداً)</th>
                  <th className="px-4 py-3 text-indigo-400">فيزا</th>
                  <th className="px-4 py-3 text-emerald-400">كليك</th>
                  <th className="px-4 py-3 text-purple-400">تطبيقات دليفري</th>
                  <th className="px-4 py-3 text-white">المجموع الإجمالي</th>
                  <th className="px-4 py-3 text-center">تعديل محاسبي</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-900 text-slate-300">
                {pagedRecords.length > 0 ? (
                  pagedRecords.map((row) => {
                    const isEditing = editingRowId === row.id;
                    return (
                      <tr key={row.id} className="hover:bg-slate-900/50 transition-colors">
                        <td className="px-4 py-3.5 font-mono text-slate-500 text-[10px]">{row.id}</td>
                        <td className="px-4 py-3.5 text-slate-200">{new Date(row.date).toLocaleDateString("ar-JO", { month: "short", day: "numeric" })}</td>
                        <td className="px-4 py-3.5">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-black ${row.branch === "G" ? "bg-amber-950/60 text-amber-500" : "bg-teal-950/60 text-teal-500"}`}>
                            {row.branchAr}
                          </span>
                        </td>
                        <td className="px-4 py-3.5 max-w-[120px] truncate">{row.deptAr}</td>
                        <td className="px-4 py-3.5 text-slate-400">{row.cashierAr}</td>
                        
                        {/* Cash cell */}
                        <td className="px-4 py-3.5 text-slate-100">
                          {isEditing ? (
                            <input
                              type="number"
                              value={rowEditState.cash ?? 0}
                              onChange={(e) => handleEditFieldChange("cash", e.target.value)}
                              className="w-16 bg-slate-900 border border-slate-700/60 rounded px-1.5 py-0.5 text-white text-xs text-center outline-none"
                            />
                          ) : (
                            formatCurrency(row.cash)
                          )}
                        </td>

                        {/* Visa cell */}
                        <td className="px-4 py-3.5 text-slate-100">
                          {isEditing ? (
                            <input
                              type="number"
                              value={rowEditState.visa ?? 0}
                              onChange={(e) => handleEditFieldChange("visa", e.target.value)}
                              className="w-16 bg-slate-900 border border-slate-700/60 rounded px-1.5 py-0.5 text-white text-xs text-center outline-none"
                            />
                          ) : (
                            formatCurrency(row.visa)
                          )}
                        </td>

                        {/* Cliq cell */}
                        <td className="px-4 py-3.5 text-slate-100 font-mono">
                          {isEditing ? (
                            <input
                              type="number"
                              value={rowEditState.klik ?? 0}
                              onChange={(e) => handleEditFieldChange("klik", e.target.value)}
                              className="w-16 bg-slate-900 border border-slate-700/60 rounded px-1.5 py-0.5 text-white text-xs text-center outline-none"
                            />
                          ) : (
                            formatCurrency(row.klik)
                          )}
                        </td>

                        {/* Apps cell */}
                        <td className="px-4 py-3.5 text-slate-100 font-mono">
                          {isEditing ? (
                            <input
                              type="number"
                              value={rowEditState.orders ?? 0}
                              onChange={(e) => handleEditFieldChange("orders", e.target.value)}
                              className="w-16 bg-slate-900 border border-slate-700/60 rounded px-1.5 py-0.5 text-white text-xs text-center outline-none"
                            />
                          ) : (
                            formatCurrency(row.orders + row.cream + row.ashyaei + row.callcenter)
                          )}
                        </td>

                        {/* row total */}
                        <td className="px-4 py-3.5 font-bold text-white font-mono">
                          {formatCurrency(row.total)}
                        </td>

                        <td className="px-4 py-3.5 text-center">
                          {isEditing ? (
                            <button
                              onClick={() => saveEdit(row.id)}
                              className="bg-emerald-600 hover:bg-emerald-500 text-white rounded p-1 shadow-md inline-flex items-center"
                            >
                              <Check className="w-3.5 h-3.5" />
                            </button>
                          ) : (
                            <button
                              onClick={() => startEdit(row)}
                              className="text-slate-500 hover:text-[#e8a030] p-1 inline-flex items-center"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </td>
                      </tr>
                    );
                  })
                ) : (
                  <tr>
                    <td colSpan={11} className="text-center py-8 text-slate-500 font-bold">
                      عفواً، لا توجد معاملات ماليّة تطابق شروط التصفية أو البحث لإظهارها.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* Table pagination UI */}
          {pageCount > 1 && (
            <div className="p-4 border-t border-slate-850 bg-slate-900 flex items-center justify-between">
              <span className="text-slate-500 text-[11px] font-bold">
                عرض الصفحات: {auditPage + 1} من {pageCount} (إجمالي السجلات المطابقة: {filteredAuditRecords.length})
              </span>
              
              <div className="flex items-center gap-1">
                <button
                  onClick={() => setAuditPage(prev => Math.max(0, prev - 1))}
                  disabled={auditPage === 0}
                  className="p-1.5 rounded-lg border border-slate-800 hover:bg-slate-850 text-slate-300 disabled:opacity-30 disabled:hover:bg-transparent transition-all"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setAuditPage(prev => Math.min(pageCount - 1, prev + 1))}
                  disabled={auditPage === pageCount - 1}
                  className="p-1.5 rounded-lg border border-slate-800 hover:bg-slate-850 text-slate-300 disabled:opacity-30 disabled:hover:bg-transparent transition-all"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </div>
      </motion.div>

    </motion.div>
  );
}
