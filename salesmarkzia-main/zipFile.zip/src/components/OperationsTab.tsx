import React from "react";
import { DashboardData } from "../types";
import { formatCurrency, formatPercent } from "../lib/utils";
import { ComposedChart, Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Tooltip, Legend } from "recharts";
import { Store, Smartphone, UtensilsCrossed, CreditCard, Users, ArrowUpRight, TrendingUp, Sparkles, AlertCircle } from "lucide-react";
import { motion } from "motion/react";

const COLORS = ["#c76f00", "#0d9488", "#5b21b6", "#d97706", "#16a34a", "#0284c7", "#7c3aed", "#ea580c"];

export function OperationsTab({ data }: { data: DashboardData }) {
  const { operational, ai } = data;

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: { staggerChildren: 0.08 }
    }
  };

  const item = {
    hidden: { opacity: 0, scale: 0.98, y: 15 },
    show: { opacity: 1, scale: 1, y: 0, transition: { type: "spring" as const, stiffness: 260, damping: 22 } }
  };

  return (
    <motion.div variants={container} initial="hidden" animate="show" className="space-y-8 select-none font-sans">
      
      {/* Operation Insight banner */}
      <motion.div variants={item} className="p-6 md:p-8 rounded-[2rem] bg-gradient-to-r from-teal-950 via-[#0a1815] to-slate-900 border border-teal-500/20 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-1 bg-teal-500/10 border border-teal-500/30 text-teal-400 px-3 py-1 rounded-full text-[10px] font-black tracking-wider leading-none">
            <Sparkles className="w-3 h-3 animate-pulse" />
            <span>رؤية العمليات والربحية</span>
          </div>
          <h3 className="text-xl font-black text-white leading-tight">الفعاليّة التوزيعيّة للقنوات والمقبوضات</h3>
          <p className="text-slate-300 text-xs font-bold leading-relaxed max-w-3xl">
            {ai.whatHappened || "يتصدر فرع خلدا مستوى الإيرادات بحصته الكبرى من المجموع المبيعاتي، نلاحظ تحسن الطلب الرقمي وسرعة تسوية الدفع لمقبوضات كلك والفيزا."}
          </p>
        </div>
        
        <div className="bg-white/5 border border-white/10 px-5 py-3.5 rounded-2xl flex-shrink-0 flex items-center gap-3">
          <div className="w-9 h-9 bg-teal-500/15 text-teal-400 rounded-xl flex items-center justify-center">
            <TrendingUp className="w-4.5 h-4.5" />
          </div>
          <div>
            <p className="text-[10px] text-slate-400 font-bold">نمو الكفاءة المقدر</p>
            <p className="text-sm font-extrabold text-white mt-0.5">↑ 8.4% الدورة الممتدة</p>
          </div>
        </div>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        {/* Pie: Branches */}
        <motion.div variants={item}>
          <OperationPieCard 
            title="مساهمة الفروع المالية" 
            subtitle="قياس الحصص المالية ومعدلات تغطية الفروع الرئيسية"
            icon={Store} 
            data={operational.byBranch} 
          />
        </motion.div>

        {/* Pie: Channels */}
        <motion.div variants={item}>
          <OperationPieCard 
            title="توزيع قنوات البيع والطلب" 
            subtitle="مقارنة مبيعات الصالة، وبطاقات الدفع المعلقة والطلبات المباشرة"
            icon={Smartphone} 
            data={operational.byChannel} 
          />
        </motion.div>

        {/* Pie: Payment Methods */}
        <motion.div variants={item}>
          <OperationPieCard 
            title="طرق ومستقبِلات الدفع النشطة" 
            subtitle="توزيع المقبوضات بين النقد، كلك، الفيزا وتطبيقات التوصيل"
            icon={CreditCard} 
            data={operational.byPaymentMethod} 
          />
        </motion.div>

        {/* Pie: Top Departments */}
        <motion.div variants={item}>
          <OperationPieCard 
            title="الحصص التشغيلية للأقسام والملحمة" 
            subtitle="توزع المبيعات للأعمدة التسويقية الثمانية الأعلى"
            icon={UtensilsCrossed} 
            data={operational.byDepartment.slice(0, 8)} 
          />
        </motion.div>

        {/* Details List: Branch Analysis Table */}
        <motion.div variants={item} className="bg-white rounded-[2.5rem] p-8 shadow-sm border border-slate-200/60 overflow-hidden relative group hover:border-[#c76f00]/30 hover:shadow-md transition-all">
          <div className="absolute -right-4 -top-4 w-32 h-32 bg-amber-50/50 rounded-full blur-3xl pointer-events-none"></div>
          <div className="flex items-center justify-between mb-8 relative z-10">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-amber-50 text-[#c76f00] flex items-center justify-center border border-amber-100">
                <Store className="w-5 h-5" />
              </div>
              <h3 className="text-base font-black text-slate-900 tracking-tight">تفصيل الأداء الكلي للفروع</h3>
            </div>
            <span className="text-[10px] text-[#c76f00] font-black bg-amber-50 px-3 py-1.5 rounded-full">تحليل القنوات</span>
          </div>
          
          <div className="space-y-3 relative z-10">
            {operational.byBranch.map((branch, index) => {
              const bgOpacity = index === 0 ? "bg-amber-50/40 border-amber-150" : "border-slate-100/50";
              const numColor = index === 0 ? "bg-amber-100 text-[#c76f00]" : "bg-slate-100 text-slate-500";
              return (
                <div key={branch.name} className={`flex items-center justify-between p-4 rounded-2xl border ${bgOpacity} hover:bg-slate-50/50 hover:border-amber-200 transition-all group/item`}>
                  <div className="flex items-center gap-4">
                    <span className={`w-8 h-8 rounded-full ${numColor} flex items-center justify-center text-xs font-black transition-colors`}>
                      {index + 1}
                    </span>
                    <div>
                      <span className="text-xs font-extrabold text-slate-800 block">{branch.name}</span>
                      <span className="text-[10px] text-slate-400 font-bold block mt-0.5">المساهمة الحقيقية مبيعاتياً: {formatPercent(branch.share)}</span>
                    </div>
                  </div>
                  <div className="text-left flex items-center gap-4">
                    <div>
                      <p className="font-black text-slate-900 text-base">{formatCurrency(branch.value)}</p>
                      <p className={`text-[10px] font-black ${branch.growth >= 0 ? "text-emerald-500" : "text-rose-500"} mt-0.5`}>
                        {branch.growth >= 0 ? "+" : ""}{formatPercent(branch.growth)} كفاءة وبقعة نمو
                      </p>
                    </div>
                    <div className="h-8 w-8 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-center text-slate-400 group-hover/item:bg-[#c76f00]/10 group-hover/item:text-[#c76f00] transition-colors">
                      <ArrowUpRight className="w-4 h-4" />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </motion.div>

        {/* Cashiers Performance Card */}
        <motion.div variants={item} className="bg-white rounded-[2.5rem] p-8 shadow-sm border border-slate-200/60 overflow-hidden relative group hover:border-[#c76f00]/30 hover:shadow-md transition-all">
          <div className="absolute -left-4 -bottom-4 w-32 h-32 bg-teal-50/50 rounded-full blur-3xl pointer-events-none"></div>
          <div className="flex items-center justify-between mb-8 relative z-10">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-teal-50 text-[#0d9488] flex items-center justify-center border border-teal-100">
                <Users className="w-5 h-5" />
              </div>
              <h3 className="text-base font-black text-slate-900 tracking-tight">أداء وكفاءة كاشيرات نقاط البيع</h3>
            </div>
            <span className="text-[10px] text-teal-600 font-semibold bg-teal-50 px-3 py-1.5 rounded-full">ساعات الفواتير</span>
          </div>
          
          <div className="space-y-3 relative z-10 max-h-[360px] overflow-y-auto pr-1">
            {operational.bySalesperson.map((cashier, index) => (
              <div key={cashier.name} className="flex items-center justify-between p-4 rounded-2xl border border-slate-100/50 hover:bg-slate-50/60 transition-colors group/item">
                <div className="flex items-center gap-4">
                  <span className="w-8 h-8 rounded-full bg-[#f0fdfa] text-teal-600 border border-teal-100 flex items-center justify-center text-xs font-black group-hover/item:scale-105 transition-all">
                    {index + 1}
                  </span>
                  <div>
                    <span className="text-xs font-extrabold text-slate-800 block">{cashier.name}</span>
                    <span className="text-[10px] text-slate-400 font-bold block mt-0.5">رتبة تسليم العهدة المالية والعمليات</span>
                  </div>
                </div>
                <div className="text-left">
                  <p className="font-black text-slate-900 text-base">{formatCurrency(cashier.value)}</p>
                  <p className="text-[10px] text-teal-600 bg-teal-50 px-2.5 py-0.5 rounded-md font-black inline-block mt-1">{cashier.invoices} فاتورة مكتملة</p>
                </div>
              </div>
            ))}
          </div>
        </motion.div>

      </div>
    </motion.div>
  );
}

function OperationPieCard({ title, subtitle, icon: Icon, data }: any) {
  // Calculate total to render percentages beautifully in Tooltip
  const sumVal = data.reduce((s: number, d: any) => s + (d.value || 0), 0) || 1;

  // Determine colors based on title contents
  let colorStart = "#c76f00";
  let colorEnd = "#f59e0b";
  let gradientId = `grad-${title.replace(/\s+/g, '-')}`;
  let badgeBg = "bg-amber-50 text-[#c76f00] border-amber-100";

  if (title.includes("قنوات")) {
    colorStart = "#4B3A5A";
    colorEnd = "#D147BD";
    badgeBg = "bg-fuchsia-50 text-[#D147BD] border-fuchsia-100";
  } else if (title.includes("الدفع")) {
    colorStart = "#0d9488";
    colorEnd = "#14b8a6";
    badgeBg = "bg-teal-50 text-teal-600 border-teal-100";
  } else if (title.includes("الأقسام")) {
    colorStart = "#312e81";
    colorEnd = "#4f46e5";
    badgeBg = "bg-indigo-50 text-indigo-600 border-indigo-100";
  }

  // Sort data descending so largest items appear at the top
  const sortedData = [...data].sort((a, b) => b.value - a.value);

  return (
    <div className="bg-white rounded-[2.5rem] p-8 shadow-sm border border-slate-200/60 flex flex-col relative overflow-hidden group hover:border-[#c76f00]/30 hover:shadow-md transition-all h-[420px]">
      <div className="absolute -left-4 -bottom-4 w-32 h-32 bg-slate-50 rounded-full blur-3xl pointer-events-none"></div>
      
      <div className="flex items-center justify-between mb-4 relative z-10 pb-4 border-b border-slate-50">
        <div className="flex items-center gap-3">
          <div className={`w-10 h-10 rounded-2xl flex items-center justify-center border ${badgeBg}`}>
            <Icon className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-black text-slate-900 tracking-tight leading-none">{title}</h3>
            {subtitle && <p className="text-[10px] text-slate-400 font-bold mt-1.5 leading-none">{subtitle}</p>}
          </div>
        </div>
      </div>
      
      <div className="flex-1 w-full relative z-10 min-h-0">
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart
            layout="vertical"
            data={sortedData}
            margin={{ top: 10, right: 10, bottom: 10, left: 10 }}
          >
            <defs>
              <linearGradient id={gradientId} x1="1" y1="0" x2="0" y2="0">
                <stop offset="0%" stopColor={colorStart} stopOpacity={0.95} />
                <stop offset="100%" stopColor={colorEnd} stopOpacity={0.7} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#F1F5F9" />
            <XAxis 
              type="number" 
              tick={{ fill: "#64748b", fontSize: 10, fontWeight: "700" }} 
              tickFormatter={(val) => `${new Intl.NumberFormat("en-US", { notation: "compact", maximumFractionDigits: 1 }).format(val)}`}
              axisLine={false} 
              tickLine={false} 
            />
            <YAxis 
              orientation="right" 
              type="category" 
              dataKey="name" 
              tick={{ fill: "#334155", fontSize: 10, fontWeight: "800" }} 
              axisLine={false} 
              tickLine={false} 
              width={105}
              dx={5}
            />
            <Tooltip 
              formatter={(value: number) => [
                <span className="font-extrabold text-slate-900">{formatCurrency(value)} ({formatPercent(value / sumVal)})</span>, 
                <span className="text-slate-500 font-bold">السيولة</span>
              ]}
              contentStyle={{ borderRadius: "20px", border: "1px solid #f1f5f9", boxShadow: "0 10px 15px -3px rgb(0 0 0 / 0.05)", padding: "12px 16px", textAlign: "right" }}
            />
            <Bar 
              dataKey="value" 
              fill={`url(#${gradientId})`} 
              radius={[0, 8, 8, 0]} 
              barSize={16}
              name="السيولة"
            />
          </ComposedChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
