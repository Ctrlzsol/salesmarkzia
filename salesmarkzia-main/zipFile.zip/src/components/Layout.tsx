import React, { useState } from "react";
import { DashboardData, SaleRecord } from "../types";
import {
  LayoutDashboard,
  Building2,
  TrendingUp,
  BrainCircuit,
  ShieldCheck,
  LogOut,
  Sliders,
  Bell,
  Search,
  Coins,
  Store
} from "lucide-react";
import { OverviewTab } from "./OverviewTab";
import { OperationsTab } from "./OperationsTab";
import { BITab } from "./BITab";
import { AITab } from "./AITab";
import { QualityTab } from "./QualityTab";
import { motion, AnimatePresence } from "motion/react";

interface LayoutProps {
  data: DashboardData;
  scenario: number;
  setScenario: (val: number) => void;
  onReset: () => void;
  records: SaleRecord[];
  onUpdateRecord: (id: string, field: keyof SaleRecord, value: number) => void;
  filterStates: {
    filterBranch: string;
    setFilterBranch: (v: string) => void;
    filterCat: string;
    setFilterCat: (v: string) => void;
    filterDept: string;
    setFilterDept: (v: string) => void;
    filterCashier: string;
    setFilterCashier: (v: string) => void;
    filterDay: string;
    setFilterDay: (v: string) => void;
    filterMonth: string;
    setFilterMonth: (v: string) => void;
    branchOptions: string[];
    catOptions: string[];
    deptOptions: string[];
    cashierOptions: string[];
    dayOptions: string[];
    monthOptions: string[];
    onClearAll: () => void;
  };
}

export function Layout({ 
  data, 
  scenario, 
  setScenario, 
  onReset,
  records,
  onUpdateRecord,
  filterStates
}: LayoutProps) {
  const [activeTab, setActiveTab] = useState("overview");
  const [currencySymbol, setCurrencySymbol] = useState(localStorage.getItem("active_currency") || "JOD");

  const handleCurrencyChangeLocal = (code: string) => {
    localStorage.setItem("active_currency", code);
    setCurrencySymbol(code);
    // Reload window to instantly propagate currency formatters across Intl instance cache
    window.location.reload();
  };

  const tabs = [
    { id: "overview", label: "الرئيسية والمؤشرات", icon: LayoutDashboard },
    { id: "operations", label: "أداء الفروع والعمليات", icon: Building2 },
    { id: "bi", label: "مصفوفة التحليل المتقدم", icon: TrendingUp },
    { id: "ai", label: "التوصيات الذكية (AI)", icon: BrainCircuit },
    { id: "quality", label: "مراجعة وتعديل السجلات", icon: ShieldCheck },
  ];

  const dayNamesAr: Record<string, string> = {
    Mon: "الاثنين",
    Tue: "الثلاثاء",
    Wed: "الأربعاء",
    Thu: "الخميس",
    Fri: "الجمعة",
    Sat: "السبت",
    Sun: "الأحد"
  };

  return (
    <div className="flex bg-[#F3F4F6] h-screen overflow-hidden text-slate-800 antialiased select-none font-sans relative">
      {/* Absolute Decorative Glows */}
      <div className="absolute top-0 right-1/4 w-[500px] h-[500px] bg-amber-500/5 rounded-full blur-[120px] pointer-events-none z-0"></div>
      <div className="absolute bottom-0 left-1/3 w-[600px] h-[600px] bg-indigo-500/5 rounded-full blur-[140px] pointer-events-none z-0"></div>

      {/* Sidebar Desktop */}
      <aside className="hidden lg:flex w-[290px] bg-slate-950 text-slate-300 flex-col shadow-2xl relative z-20 border-l border-slate-900">
        <div className="p-8 pb-6 flex items-center gap-4 border-b border-slate-900/60 bg-slate-950">
          <div className="w-12 h-12 bg-gradient-to-tr from-[#c76f00] to-[#f59e0b] rounded-2xl flex items-center justify-center shadow-lg shadow-amber-500/10 hover:rotate-6 transition-transform">
            <Store className="w-5.5 h-5.5 text-white" />
          </div>
          <div>
            <h1 className="text-white font-extrabold text-lg leading-tight tracking-tight">المركزية التشغيلية</h1>
            <p className="text-amber-400 text-[10px] font-black tracking-widest mt-0.5">AL-MARKAZIA</p>
          </div>
        </div>

        <nav className="flex-1 px-4 space-y-2 overflow-y-auto mt-6">
          <div className="text-slate-500 text-[10px] font-black uppercase tracking-wider mb-3 px-4">أقسام التحليل المالي والتدقيق</div>
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`w-full group relative flex items-center gap-4 px-4 py-4 rounded-2xl font-bold transition-all duration-300 overflow-hidden ${
                  isActive
                    ? "text-white bg-slate-900 shadow-inner border border-slate-800"
                    : "text-slate-400 hover:text-slate-200 hover:bg-slate-900/30"
                }`}
              >
                {isActive && (
                  <motion.div 
                    layoutId="activeTabIndicator" 
                    className="absolute right-0 top-0 bottom-0 w-1.5 bg-amber-500 rounded-l-full shadow-[0_0_12px_rgba(245,158,11,0.5)]"
                  ></motion.div>
                )}
                <Icon className={`w-5 h-5 transition-transform group-hover:scale-105 duration-300 ${isActive ? "text-amber-500" : "text-slate-500 group-hover:text-slate-400"}`} />
                <span className="text-xs font-black tracking-wide">{tab.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="p-6 border-t border-slate-900 bg-slate-950/80">
          <button 
            onClick={onReset} 
            className="w-full group flex items-center justify-center gap-2.5 px-4 py-4 text-rose-400 text-xs font-black hover:bg-rose-500/10 rounded-2xl transition-all border border-transparent hover:border-rose-500/20 shadow-xs"
          >
            <LogOut className="w-4.5 h-4.5 transition-transform group-hover:-translate-x-1" />
            تجديد الجلسة والمطابقة
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col h-screen relative overflow-hidden bg-[#F3F4F6] z-10">
        {/* Header */}
        <header className="h-[90px] bg-white border-b border-slate-200/60 flex flex-shrink-0 items-center justify-between px-6 md:px-10 relative z-10 shadow-sm">
          <div className="flex items-center gap-4 text-slate-800">
             <div className="h-12 w-12 bg-amber-50 rounded-2xl flex items-center justify-center border border-amber-100/80 shadow-xs group cursor-pointer">
                <Search className="w-5 h-5 text-[#c76f00] group-hover:scale-110 transition-transform" />
             </div>
             <div>
               <h2 className="text-lg font-black text-slate-900 tracking-tight leading-none">المركزية – لوحة التحليل ومطابقة الفروع</h2>
               <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1.5">AL-MARKAZIA POS ANALYSIS ENGINE</p>
             </div>
          </div>
          
          <div className="flex items-center gap-4 print:hidden">
            {/* Currency Selector locked to JOD */}
            <div className="flex items-center gap-2 bg-amber-50 border border-amber-200/50 px-4 py-2.5 rounded-2xl text-[#c76f00] font-black text-xs select-none">
                <Coins className="w-4 h-4 text-[#c76f00]" />
                <span>دينار أردني (JOD)</span>
            </div>

            <button className="h-11 w-11 relative bg-white border border-slate-200 rounded-2xl flex items-center justify-center text-slate-400 hover:text-slate-600 hover:bg-slate-50 transition-all shadow-xs">
                <Bell className="w-4.5 h-4.5" />
                <span className="absolute top-3 right-3 w-2.5 h-2.5 bg-rose-500 rounded-full border-2 border-white"></span>
            </button>
            <div className="h-6 w-px bg-slate-200 mx-1"></div>
            <button 
              onClick={() => window.print()} 
              className="bg-slate-900 hover:bg-slate-800 text-white px-6 py-3 rounded-2xl text-xs font-black shadow-lg shadow-slate-900/15 hover:shadow-slate-900/25 transition-all flex items-center gap-2 hover:scale-[1.02] active:scale-[0.98]"
            >
              <span>تصدير PDF</span>
            </button>
          </div>
        </header>

        {/* Dynamic Pos Filter Bar */}
        <div className="bg-white/80 backdrop-blur-md border-b border-slate-200/60 px-6 md:px-10 py-4.5 sticky top-0 z-10 flex flex-wrap items-center gap-3.5 print:hidden shadow-xs">
          <div className="text-[10px] font-black uppercase text-amber-600 tracking-wider flex items-center gap-2 ml-2">
            <Sliders className="w-4 h-4 text-[#c76f00]" />
            <span>تصفية السجل المالي:</span>
          </div>

          {/* Growth Scenario Slider Control */}
          <div className="flex items-center gap-3 bg-slate-50 border border-slate-200 rounded-2xl px-4 py-2 text-xs font-bold text-slate-705 shadow-xs select-none">
            <span className="text-amber-700 font-extrabold whitespace-nowrap">محاكاة النمو: <span className="font-black font-mono text-xs">{Math.round(scenario * 100)}%</span></span>
            <input
              type="range"
              min="0.5"
              max="1.5"
              step="0.05"
              value={scenario}
              onChange={(e) => setScenario(parseFloat(e.target.value))}
              className="w-24 h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-amber-500 outline-none"
            />
          </div>
          
          {/* Filter Branch */}
          <select
            value={filterStates.filterBranch}
            onChange={(e) => filterStates.setFilterBranch(e.target.value)}
            className="bg-slate-50 border border-slate-200 rounded-2xl px-4 py-2.5 text-xs font-black text-slate-705 outline-none focus:border-amber-500 focus:bg-white focus:ring-1 focus:ring-amber-500/20 transition-all cursor-pointer shadow-xs"
          >
            <option value="">كل الفروع</option>
            {filterStates.branchOptions.map(b => (
              <option key={b} value={b}>{b === "G" ? "الجاردنز" : b === "K" ? "خلدا" : "أخرى"}</option>
            ))}
          </select>

          {/* Filter Category */}
          <select
            value={filterStates.filterCat}
            onChange={(e) => filterStates.setFilterCat(e.target.value)}
            className="bg-slate-50 border border-slate-200 rounded-2xl px-4 py-2.5 text-xs font-black text-slate-705 outline-none focus:border-amber-500 focus:bg-white focus:ring-1 focus:ring-amber-500/20 transition-all cursor-pointer shadow-xs"
          >
            <option value="">كل التصنيفات</option>
            {filterStates.catOptions.map(c => (
              <option key={c} value={c}>{c === "R" ? "مطعم" : c === "A" ? "تطبيقات" : "أخرى"}</option>
            ))}
          </select>

          {/* Filter Dept */}
          <select
            value={filterStates.filterDept}
            onChange={(e) => filterStates.setFilterDept(e.target.value)}
            className="bg-slate-50 border border-slate-200 rounded-2xl px-4 py-2.5 text-xs font-black text-slate-705 outline-none focus:border-amber-500 focus:bg-white focus:ring-1 focus:ring-amber-500/20 transition-all cursor-pointer shadow-xs max-w-[200px]"
          >
            <option value="">كل الأقسام</option>
            {filterStates.deptOptions.map(d => (
              <option key={d} value={d}>{d}</option>
            ))}
          </select>

          {/* Filter Cashier */}
          <select
            value={filterStates.filterCashier}
            onChange={(e) => filterStates.setFilterCashier(e.target.value)}
            className="bg-slate-50 border border-slate-200 rounded-2xl px-4 py-2.5 text-xs font-black text-slate-705 outline-none focus:border-amber-500 focus:bg-white focus:ring-1 focus:ring-amber-500/20 transition-all cursor-pointer shadow-xs"
          >
            <option value="">كل الكاشيرات</option>
            {filterStates.cashierOptions.map(k => (
              <option key={k} value={k}>{k}</option>
            ))}
          </select>

          {/* Filter Day */}
          <select
            value={filterStates.filterDay}
            onChange={(e) => filterStates.setFilterDay(e.target.value)}
            className="bg-slate-50 border border-slate-200 rounded-2xl px-4 py-2.5 text-xs font-black text-slate-705 outline-none focus:border-amber-500 focus:bg-white focus:ring-1 focus:ring-amber-500/20 transition-all cursor-pointer shadow-xs"
          >
            <option value="">كل الأيام</option>
            {filterStates.dayOptions.map(d => (
              <option key={d} value={d}>{dayNamesAr[d] || d}</option>
            ))}
          </select>

          {/* Filter Month */}
          <select
            value={filterStates.filterMonth}
            onChange={(e) => filterStates.setFilterMonth(e.target.value)}
            className="bg-[#FFFBEB] border border-amber-300 text-amber-800 rounded-2xl px-4 py-2.5 text-xs font-extrabold outline-none focus:border-amber-500 focus:bg-white transition-all cursor-pointer shadow-xs"
          >
            <option value="">كل الأشهر المتاحة</option>
            {filterStates.monthOptions.map(m => {
              const [yr, mn] = m.split("-");
              const monthsAr = [
                "يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
                "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"
              ];
              const monthName = monthsAr[parseInt(mn, 10) - 1] || mn;
              return (
                <option key={m} value={m}>{monthName} {yr}</option>
              );
            })}
          </select>

          {/* Clear All */}
          {(filterStates.filterBranch || filterStates.filterCat || filterStates.filterDept || filterStates.filterCashier || filterStates.filterDay || filterStates.filterMonth) && (
            <button
              onClick={filterStates.onClearAll}
              className="text-xs font-extrabold text-rose-600 bg-rose-50 border border-rose-200/50 px-5 py-2.5 rounded-2xl hover:bg-rose-100 transition-colors mr-auto shadow-xs active:scale-95"
            >
              إلغاء الفلاتر ×
            </button>
          )}
        </div>

        <div className="p-4 md:p-8 pt-6 md:pt-8 overflow-y-auto flex-1 h-full scroll-smooth">
          <div className="max-w-[1500px] mx-auto pb-24 lg:pb-16">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                transition={{ duration: 0.25, ease: "easeOut" }}
              >
                {activeTab === "overview" && (
                  <OverviewTab 
                    data={data} 
                    records={records} 
                    onUpdateRecord={onUpdateRecord} 
                    filterStates={filterStates}
                    scenario={scenario}
                  />
                )}
                {activeTab === "operations" && <OperationsTab data={data} />}
                {activeTab === "bi" && <BITab data={data} />}
                {activeTab === "ai" && <AITab data={data} />}
                {activeTab === "quality" && (
                  <QualityTab 
                    data={data} 
                    records={records} 
                    onUpdateRecord={onUpdateRecord} 
                  />
                )}
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </main>

      {/* Mobile Bottom Navigation */}
      <div className="lg:hidden fixed bottom-0 left-0 right-0 bg-slate-950 text-slate-400 border-t border-slate-900 z-50 px-2 py-2 flex items-center justify-around pb-safe">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex flex-col items-center p-2 rounded-2xl transition-all ${
                isActive ? "text-amber-500" : "hover:text-slate-200"
              }`}
            >
              <Icon className={`w-5.5 h-5.5 mb-1 ${isActive ? "text-amber-400" : "text-slate-500"}`} />
              <span className="text-[9px] font-black">{tab.label.split(" ")[0]}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
