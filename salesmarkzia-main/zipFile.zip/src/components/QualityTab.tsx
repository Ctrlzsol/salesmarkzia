import React, { useState } from "react";
import { DashboardData, SaleRecord } from "../types";
import { formatNumber, formatCurrency } from "../lib/utils";
import { ShieldAlert, ShieldCheck, Database, FileX, CopySlash, CheckCircle2, Search, Sliders, ArrowLeft, ArrowRight } from "lucide-react";
import { motion } from "motion/react";

interface QualityTabProps {
  data: DashboardData;
  records: SaleRecord[];
  onUpdateRecord: (id: string, field: keyof SaleRecord, value: number) => void;
}

export function QualityTab({ data, records, onUpdateRecord }: QualityTabProps) {
  const { quality } = data;
  const isGood = quality.score >= 90;

  // Search & Pagination States
  const [searchTerm, setSearchTerm] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const rowsPerPage = 12;

  // Filter local rows
  const filteredRows = records.filter((row) => {
    return (
      row.deptAr?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      row.cashierAr?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      row.dayAr?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      row.branchAr?.toLowerCase().includes(searchTerm.toLowerCase())
    );
  });

  // Paginated Rows
  const totalPages = Math.ceil(filteredRows.length / rowsPerPage) || 1;
  const startIndex = (currentPage - 1) * rowsPerPage;
  const paginatedRows = filteredRows.slice(startIndex, startIndex + rowsPerPage);

  const handlePageChange = (newPage: number) => {
    if (newPage >= 1 && newPage <= totalPages) {
      setCurrentPage(newPage);
    }
  };

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };

  const item = {
    hidden: { opacity: 0, scale: 0.95, y: 15 },
    show: { opacity: 1, scale: 1, y: 0, transition: { type: "spring" as const, stiffness: 300, damping: 24 } }
  };

  return (
    <motion.div variants={container} initial="hidden" animate="show" className="space-y-8">
      {/* Quality Score Hero Card */}
      <motion.div variants={item} className="bg-white rounded-3xl p-8 shadow-sm border border-slate-200/60 flex flex-col md:flex-row items-center gap-10 relative overflow-hidden group hover:shadow-md transition-all">
        <div className="absolute -right-20 -top-20 w-64 h-64 bg-indigo-50/50 rounded-full blur-3xl pointer-events-none"></div>
        <div className="relative flex-shrink-0 z-10 w-48 h-48">
          <svg className="w-full h-full transform -rotate-90 drop-shadow-md">
            <circle cx="96" cy="96" r="80" className="stroke-slate-100" strokeWidth="10" fill="none" />
            <motion.circle 
              initial={{ strokeDashoffset: 2 * Math.PI * 80 }}
              animate={{ strokeDashoffset: 2 * Math.PI * 80 * (1 - quality.score / 100) }}
              transition={{ duration: 1.5, ease: "easeOut" }}
              cx="96" cy="96" r="80" 
              className={`${isGood ? "stroke-emerald-500" : "stroke-amber-500"}`} 
              strokeWidth="10" 
              fill="none" 
              strokeDasharray={2 * Math.PI * 80} 
              strokeLinecap="round"
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className="text-3xl font-black text-slate-900">{quality.score}%</span>
            <span className="text-[10px] uppercase font-bold tracking-widest text-slate-400 mt-1">جودة الحسابات</span>
          </div>
        </div>

        <div className="flex-1 space-y-8 w-full relative z-10">
          <div className="flex items-center gap-4">
            <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shadow-sm ${isGood ? 'bg-emerald-50 border border-emerald-100 text-emerald-600' : 'bg-amber-50 border border-amber-100 text-amber-600'}`}>
               {isGood ? (
                 <ShieldCheck className="w-6 h-6" />
               ) : (
                 <ShieldAlert className="w-6 h-6" />
               )}
            </div>
            <div>
              <h3 className="text-xl font-black text-slate-900 tracking-tight">
                {isGood ? "البيانات مطابقة ومتوازنة محاسبياً" : "توجد بعض الاختلافات الطفيفة في مقارنات الفروع"}
              </h3>
              <p className="text-slate-500 text-sm font-bold mt-1">
                تم استخلاص وتحليل {formatNumber(records.length)} سجل مالي من تقارير المبيعات بنجاح.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 border-t border-slate-100 pt-6">
            <div className="bg-slate-50/80 rounded-2xl p-4 border border-slate-100 flex flex-col justify-between hover:bg-slate-100 transition-colors">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-8 h-8 rounded-xl bg-white border border-slate-200 flex items-center justify-center">
                    <FileX className="w-4 h-4 text-slate-400" />
                </div>
                <span className="text-xs font-bold text-slate-600">سجلات إجمالية</span>
              </div>
              <span className="text-xl font-black text-slate-900">{formatNumber(records.length)} سجل</span>
            </div>
            <div className="bg-slate-50/80 rounded-2xl p-4 border border-slate-100 flex flex-col justify-between hover:bg-slate-100 transition-colors">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-8 h-8 rounded-xl bg-white border border-slate-200 flex items-center justify-center">
                    <CopySlash className="w-4 h-4 text-slate-400" />
                </div>
                <span className="text-xs font-bold text-slate-600">أعمدة التدقيق المالي</span>
              </div>
              <span className="text-xl font-black text-slate-900">8 قنوات دفع</span>
            </div>
            <div className="bg-slate-50/80 rounded-2xl p-4 border border-slate-100 flex flex-col justify-between hover:bg-slate-100 transition-colors">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-8 h-8 rounded-xl bg-white border border-slate-200 flex items-center justify-center">
                    <Database className="w-4 h-4 text-slate-400" />
                </div>
                <span className="text-xs font-bold text-slate-600">اختلافات مدخلة</span>
              </div>
              <span className="text-xl font-black text-slate-950">{formatNumber(quality.potentialErrors)}</span>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Spreadsheet Editing Grid */}
      <motion.div variants={item} className="bg-white rounded-3xl shadow-sm border border-slate-200/60 overflow-hidden">
        {/* Actions bar */}
        <div className="p-6 border-b border-slate-100 bg-slate-50/50 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <Sliders className="w-5 h-5 text-[#c76f00]" />
            <span className="font-black text-slate-800 text-sm">مستكشف الدفاتر والقيود (انقر للتعديل)</span>
            <span className="bg-[#c76f00]/10 text-[#c76f00] font-black text-[10px] px-3 py-1 rounded-full uppercase tracking-wider">حي ومباشر</span>
          </div>

          <div className="relative w-full sm:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute right-4 top-3.5" />
            <input
              type="text"
              placeholder="ابحث بقسم، كاشير، فرع..."
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setCurrentPage(1);
              }}
              className="bg-white border border-slate-200 text-xs font-semibold rounded-2xl w-full pr-11 pl-4 py-3 placeholder-slate-400 text-slate-700 outline-none focus:border-[#c76f00] focus:shadow-sm transition-all"
            />
          </div>
        </div>

        {/* Dense Spreadsheet Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-right whitespace-nowrap">
            <thead className="bg-slate-50 text-slate-500 font-bold border-b border-slate-100">
              <tr>
                <th className="px-5 py-4">اليوم والتاريخ</th>
                <th className="px-5 py-4">الفرع</th>
                <th className="px-5 py-4">تحصيل الكاشير</th>
                <th className="px-5 py-4">القسم والخط</th>
                <th className="px-5 py-4 text-center">فيزا</th>
                <th className="px-5 py-4 text-center">كاش</th>
                <th className="px-5 py-4 text-center">كليك</th>
                <th className="px-5 py-4 text-center">طلبات</th>
                <th className="px-5 py-4 text-center">كريم</th>
                <th className="px-5 py-4 text-center">أشيائي</th>
                <th className="px-5 py-4 text-center">كول سنتر</th>
                <th className="px-5 py-4 text-center">أخرى</th>
                <th className="px-5 py-4 bg-slate-100 font-black text-[#c76f00] text-center">إجمالي المبيعات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {paginatedRows.map((row) => (
                <tr key={row.id} className="hover:bg-slate-50/40 transition-colors group">
                  <td className="px-5 py-3">
                    <span className="font-extrabold text-slate-800">{row.dayAr}</span>
                    <span className="block text-[10px] text-slate-400 mt-0.5">{new Date(row.date).toLocaleDateString("en-US", { month: "numeric", day: "numeric" })}</span>
                  </td>
                  <td className="px-5 py-3 font-semibold text-slate-600">
                    <span className={`inline-block px-2.5 py-1 rounded-lg text-[10px] font-black ${row.branch === "G" ? "bg-amber-50 text-amber-700" : "bg-teal-50 text-teal-700"}`}>
                       {row.branchAr}
                    </span>
                  </td>
                  <td className="px-5 py-3 font-bold text-slate-700">{row.cashierAr}</td>
                  <td className="px-5 py-3 font-bold text-slate-800">{row.deptAr}</td>
                  
                  {/* Visa Edit Cell */}
                  <td className="px-2 py-1 text-center font-sans">
                    <input
                      type="number"
                      value={row.visa || ""}
                      onChange={(e) => onUpdateRecord(row.id, "visa", parseFloat(e.target.value) || 0)}
                      className="w-16 bg-transparent border border-transparent hover:border-slate-200 focus:border-[#c76f00] focus:bg-white text-center rounded-lg p-1 font-bold text-slate-700"
                    />
                  </td>

                  {/* Cash Edit Cell */}
                  <td className="px-2 py-1 text-center font-sans">
                    <input
                      type="number"
                      value={row.cash || ""}
                      onChange={(e) => onUpdateRecord(row.id, "cash", parseFloat(e.target.value) || 0)}
                      className="w-16 bg-transparent border border-transparent hover:border-slate-200 focus:border-[#c76f00] focus:bg-white text-center rounded-lg p-1 font-bold text-slate-700"
                    />
                  </td>

                  {/* Klik Edit Cell */}
                  <td className="px-2 py-1 text-center font-sans">
                    <input
                      type="number"
                      value={row.klik || ""}
                      onChange={(e) => onUpdateRecord(row.id, "klik", parseFloat(e.target.value) || 0)}
                      className="w-16 bg-transparent border border-transparent hover:border-slate-200 focus:border-[#c76f00] focus:bg-white text-center rounded-lg p-1 font-bold text-slate-700"
                    />
                  </td>

                  {/* Orders Edit Cell */}
                  <td className="px-2 py-1 text-center font-sans">
                    <input
                      type="number"
                      value={row.orders || ""}
                      onChange={(e) => onUpdateRecord(row.id, "orders", parseFloat(e.target.value) || 0)}
                      className="w-16 bg-transparent border border-transparent hover:border-slate-200 focus:border-[#c76f00] focus:bg-white text-center rounded-lg p-1 font-bold text-slate-700"
                    />
                  </td>

                  {/* Careem Edit Cell */}
                  <td className="px-2 py-1 text-center font-sans">
                    <input
                      type="number"
                      value={row.cream || ""}
                      onChange={(e) => onUpdateRecord(row.id, "cream", parseFloat(e.target.value) || 0)}
                      className="w-16 bg-transparent border border-transparent hover:border-slate-200 focus:border-[#c76f00] focus:bg-white text-center rounded-lg p-1 font-bold text-slate-700"
                    />
                  </td>

                  {/* Ashyaei Edit Cell */}
                  <td className="px-2 py-1 text-center font-sans">
                    <input
                      type="number"
                      value={row.ashyaei || ""}
                      onChange={(e) => onUpdateRecord(row.id, "ashyaei", parseFloat(e.target.value) || 0)}
                      className="w-16 bg-transparent border border-transparent hover:border-slate-200 focus:border-[#c76f00] focus:bg-white text-center rounded-lg p-1 font-bold text-slate-700"
                    />
                  </td>

                  {/* Call Center Edit Cell */}
                  <td className="px-2 py-1 text-center font-sans">
                    <input
                      type="number"
                      value={row.callcenter || ""}
                      onChange={(e) => onUpdateRecord(row.id, "callcenter", parseFloat(e.target.value) || 0)}
                      className="w-16 bg-transparent border border-transparent hover:border-slate-200 focus:border-[#c76f00] focus:bg-white text-center rounded-lg p-1 font-bold text-slate-700"
                    />
                  </td>

                  {/* Other Edit Cell */}
                  <td className="px-2 py-1 text-center font-sans">
                    <input
                      type="number"
                      value={row.other || ""}
                      onChange={(e) => onUpdateRecord(row.id, "other", parseFloat(e.target.value) || 0)}
                      className="w-16 bg-transparent border border-transparent hover:border-slate-200 focus:border-[#c76f00] focus:bg-white text-center rounded-lg p-1 font-bold text-slate-700"
                    />
                  </td>

                  {/* Total calculation Label */}
                  <td className="px-5 py-3 bg-slate-50/50 font-black text-slate-900 text-center font-sans min-w-[90px]">
                    {formatCurrency(row.total)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination Controls */}
        <div className="p-6 bg-slate-50 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-4">
          <span className="text-xs font-bold text-slate-500">
            عرض السجلات {startIndex + 1} إلى {Math.min(startIndex + rowsPerPage, filteredRows.length)} من أصل {filteredRows.length} سجل بعد التصفية
          </span>
          
          <div className="flex items-center gap-2">
            <button
              onClick={() => handlePageChange(currentPage - 1)}
              disabled={currentPage === 1}
              className="p-2 border border-slate-200 bg-white rounded-xl text-slate-500 disabled:opacity-40 hover:bg-slate-50 transition-colors cursor-pointer"
            >
              <ArrowRight className="w-4 h-4" />
            </button>
            <span className="text-xs font-black px-4 text-slate-700">الصفحة {currentPage} من {totalPages}</span>
            <button
              onClick={() => handlePageChange(currentPage + 1)}
              disabled={currentPage === totalPages}
              className="p-2 border border-slate-200 bg-white rounded-xl text-slate-500 disabled:opacity-40 hover:bg-slate-50 transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
          </div>
        </div>
      </motion.div>

      {/* Audit Warnings logs list */}
      <motion.div variants={item} className="bg-white rounded-3xl p-8 shadow-sm border border-slate-200/60 transition-all hover:shadow-md">
        <h3 className="text-sm font-black text-slate-800 tracking-tight mb-6">المراجعات النقدية وحساب التباين</h3>
        <ul className="space-y-3">
          {quality.issues.length > 0 ? quality.issues.map((issue, idx) => (
            <li key={idx} className="flex items-start gap-4 bg-slate-50/50 p-5 rounded-2xl border border-slate-100 group hover:border-slate-200 transition-all">
              <CheckCircle2 className="w-5 h-5 text-indigo-500 mt-0.5 flex-shrink-0" />
              <span className="text-slate-700 text-xs font-bold leading-relaxed">{issue}</span>
            </li>
          )) : (
            <li className="flex items-center justify-center py-10 bg-slate-50/50 rounded-2xl border border-slate-100 border-dashed">
              <span className="text-slate-400 font-bold text-xs">البيانات خالية من الأخطاء الملحوظة. ممتاز!</span>
            </li>
          )}
        </ul>
      </motion.div>
    </motion.div>
  );
}
